import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

import '../data/services/api_service.dart';
import '../core/theme/app_theme.dart';

class TeacherController extends GetxController {
  final ApiService _apiService = Get.find();

  final isLoading = false.obs;
  final teachers = <Map<String, dynamic>>[].obs;
  final teacherAssignments = <Map<String, dynamic>>[].obs;

  // ===================== UTIL =====================

  void _showSnackbar(String title, String message, Color color) {
    Get.snackbar(
      title,
      message,
      backgroundColor: color,
      colorText: Colors.white,
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(12),
    );
  }

  String _extractError(dynamic error) {
    if (error is DioException) {
      // Handle different response types
      if (error.response?.data != null) {
        if (error.response!.data is Map && error.response!.data.containsKey('message')) {
          return error.response!.data['message'];
        } else if (error.response!.data is String) {
          // Handle HTML error responses
          return 'Server error (${error.response!.statusCode}): ${error.response!.statusMessage}';
        }
      }
      return error.message ?? 'Network error occurred';
    }
    return error.toString();
  }

  // ===================== ASSIGN / TOGGLE =====================

  Future<void> manageTeacherAssignments({
    required String teacherId,
    required List<Map<String, dynamic>> updates,
    required String schoolId,
    String? classId,
  }) async {
    // Debug: Check if updates format matches API expectations

    try {
      isLoading.value = true;

      // Try without query parameters, as the API might get schoolId from auth context
      final requestData = {
        'teacherId': teacherId,
        'updates': updates, // List of {classId, sectionId} objects
      };

      final response = await _apiService.post(
        '/api/teacher/assignments/manage',
        data: requestData,
      );

      // Check if assignments were actually saved
      final returnedAssignments = response.data['assignments'] ?? [];

      if (returnedAssignments.length != updates.length) {

      }

      if (response.data != null && response.data['ok'] == true) {
        final savedCount = returnedAssignments.length;
        final sentCount = updates.length;

        String message = response.data['message'] ?? 'Assignments updated';
        if (savedCount != sentCount) {
          message += ' (Warning: $savedCount/$sentCount assignments saved)';
        }

        _showSnackbar(
          savedCount == sentCount ? 'Success' : 'Warning',
          message,
          savedCount == sentCount ? AppTheme.successGreen : Colors.orange,
        );

        // Refresh assignments data with proper type casting
        final responseAssignments = response.data['assignments'];
        if (responseAssignments is List) {
          teacherAssignments.value = List<Map<String, dynamic>>.from(
            responseAssignments.map((item) => Map<String, dynamic>.from(item))
          );
        } else {
          teacherAssignments.value = [];
        }
      } else {
        _showSnackbar(
          'Error',
          response.data?['message'] ?? 'Failed to update assignments',
          AppTheme.errorRed,
        );
      }
    } catch (e) {
      
      _showSnackbar(
        'Error',
        _extractError(e),
        AppTheme.errorRed,
      );
    } finally {
      isLoading.value = false;
    }
  }

  // ===================== GET CLASS + SECTION =====================

  Future<List<Map<String, dynamic>>> getAllClassSectionAssignments({
    required String schoolId,
  }) async {
    try {
      isLoading.value = true;

      final response = await _apiService.get(
        '/api/teacher/getall/class/section',
        queryParameters: {'schoolId': schoolId},
      );

      if (response.data == null || response.data['data'] == null) {
        
        _showSnackbar(
          'Info',
          'No class-section data found',
          Colors.orange,
        );
        return [];
      }

      final data = List<Map<String, dynamic>>.from(response.data['data']);
      
      if (data.isNotEmpty) {
        
      }
      return data;
    } catch (e) {
      
      _showSnackbar(
        'Error',
        _extractError(e),
        AppTheme.errorRed,
      );
      return [];
    } finally {
      isLoading.value = false;
    }
  }
}
