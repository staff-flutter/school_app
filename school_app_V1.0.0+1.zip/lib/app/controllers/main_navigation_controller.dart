import 'package:get/get.dart';
import '../core/rbac/api_rbac.dart';
import '../modules/auth/controllers/auth_controller.dart';

class MainNavigationController extends GetxController {
  final selectedIndex = 0.obs;
  
  List<NavigationItem> get navigationItems {
    try {
      final authController = Get.find<AuthController>();
      final userRole = authController.user.value?.role?.toLowerCase() ?? '';
      
      switch (userRole) {
        case 'parent':
          return [
            NavigationItem(
              label: 'Dashboard',
              icon: 'dashboard',
              route: '/accounting-dashboard',
            ),
            NavigationItem(
              label: 'My Children',
              icon: 'child_care',
              route: '/my-children',
            ),
            NavigationItem(
              label: 'Clubs',
              icon: 'clubs',
              route: '/clubs-activities',
            ),

            NavigationItem(
              label: 'Profile',
              icon: 'profile',
              route: '/profile',
            ),
          ];
        case 'teacher':
          return [
            NavigationItem(
              label: 'Dashboard',
              icon: 'dashboard',
              route: '/accounting-dashboard',
            ),
            NavigationItem(
              label: 'My Classes',
              icon: 'class',
              route: '/teacher-classes',
            ),
            NavigationItem(
              label: 'Attendance',
              icon: 'attendance',
              route: '/attendance?initialTab=7',
            ),
            NavigationItem(
              label: 'Communications',
              icon: 'communications',
              route: '/communications',
            ),
            NavigationItem(
              label: 'Profile',
              icon: 'profile',
              route: '/profile',
            ),
          ];
        case 'accountant':
          return [
            NavigationItem(
              label: 'Dashboard',
              icon: 'dashboard',
              route: '/accounting-dashboard',
            ),

            NavigationItem(
              label: 'Profile',
              icon: 'profile',
              route: '/profile',
            ),
          ];
        case 'administrator':
          return [
            NavigationItem(
              label: 'Dashboard',
              icon: 'dashboard',
              route: '/accounting-dashboard',
            ),
            NavigationItem(
              label: 'School',
              icon: 'business',
              route: '/school-management',
            ),

            NavigationItem(
              label: 'Profile',
              icon: 'profile',
              route: '/profile',
            ),
          ];
        default:
          return [
            NavigationItem(
              label: 'Dashboard',
              icon: 'dashboard',
              route: '/accounting-dashboard',
            ),
            NavigationItem(
              label: 'School',
              icon: 'business',
              route: '/school-management',
            ),
            NavigationItem(
              label: 'Subscription',
              icon: 'subscription',
              route: '/subscription-management',
            ),
            NavigationItem(
              label: 'Profile',
              icon: 'profile',
              route: '/profile',
            ),
          ];
      }
    } catch (e) {
      return [
        NavigationItem(
          label: 'Dashboard',
          icon: 'dashboard',
          route: '/accounting-dashboard',
        ),
      ];
    }
  }

  void onItemTapped(int index) {
    selectedIndex.value = index;
    if (index < navigationItems.length) {
      final navigationItem = navigationItems[index];
      final route = navigationItem.route;
      if (route.isNotEmpty) {
        // Handle routes with query parameters
        if (route.contains('?')) {
          final parts = route.split('?');
          final baseRoute = parts[0];
          final queryParams = <String, String>{};

          if (parts.length > 1) {
            final paramString = parts[1];
            for (final param in paramString.split('&')) {
              final keyValue = param.split('=');
              if (keyValue.length == 2) {
                queryParams[keyValue[0]] = keyValue[1];
              }
            }
          }

          Get.toNamed(baseRoute, parameters: queryParams);
        } else {
          Get.toNamed(route);
        }
      }
    }
  }

  String get currentUserName => 'User';
  String get currentUserRole => 'Demo';
}

class NavigationItem {
  final String label;
  final String icon;
  final String route;

  NavigationItem({
    required this.label,
    required this.icon,
    required this.route,
  });
}