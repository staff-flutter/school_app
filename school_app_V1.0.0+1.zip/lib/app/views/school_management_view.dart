import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:collection/collection.dart';
import '../controllers/school_controller.dart';
import '../controllers/student_record_controller.dart';
import '../controllers/user_management_controller.dart';
import '../controllers/student_management_controller.dart';
import '../controllers/attendance_controller.dart' as old_attendance;
import '../controllers/fee_structure_controller.dart';
import '../core/theme/app_theme.dart';
import '../core/widgets/responsive_wrapper.dart';
import '../core/widgets/gradient_card.dart';
import '../core/widgets/api_rbac_wrapper.dart';
import '../core/rbac/api_rbac.dart';
import '../core/extensions/widget_extensions.dart';
import '../data/models/school_models.dart';
import '../data/models/student_model.dart';

import '../modules/auth/controllers/auth_controller.dart';
import '../widgets/fee_structure_widgets.dart';
import 'student_form_dialog.dart';
import 'student_individual_detail_view.dart';
import 'user_detail_view.dart';

import 'teacher_assignment_view.dart';

class SchoolManagementView extends GetView<SchoolController> {
  SchoolManagementView({super.key});
  final userController = Get.put(UserManagementController());

  void _initializeSchoolForUser() {
    final authController = Get.find<AuthController>();
    final userRole = authController.user.value?.role?.toLowerCase() ?? '';
    final userSchoolId = authController.user.value?.schoolId;
    
    if (!['correspondent'].contains(userRole) && userSchoolId != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final userSchool = controller.schools.firstWhereOrNull(
          (school) => school.id == userSchoolId,
        );
        if (userSchool != null) {
          controller.selectedSchool.value = userSchool;
        } else {
          controller.getAllSchools().then((_) {
            final school = controller.schools.firstWhereOrNull(
              (s) => s.id == userSchoolId,
            );
            if (school != null) {
              controller.selectedSchool.value = school;
            }
          });
        }
      });
    }
  }

  // User permissions
  bool canCreateUser(String role) => role == 'correspondent';
  bool canDeleteUser(String role) => role == 'correspondent';
  bool canEditUser(String role) => [
    'correspondent', 'teacher', 'principal', 'administrator', 'viceprincipal'
  ].contains(role);
  bool canAssignRole(String role) => ['correspondent', 'administrator'].contains(role);

  // School permissions
  bool canCreateSchool(String role) => role == 'correspondent';
  bool canEditSchool(String role) => role == 'correspondent';
  bool canDeleteSchool(String role) => role == 'correspondent';
  bool canUpdateSchoolLogo(String role) => role == 'correspondent';

  // Class permissions
  bool canCreateClass(String role) => ['correspondent', 'administrator'].contains(role);
  bool canEditClass(String role) => ['correspondent', 'administrator'].contains(role);
  bool canDeleteClass(String role) => ['correspondent', 'administrator'].contains(role);

  // Section permissions
  bool canCreateSection(String role) => ['correspondent', 'administrator'].contains(role);
  bool canEditSection(String role) => ['correspondent', 'administrator'].contains(role);
  bool canDeleteSection(String role) => role == 'correspondent';

  // Student permissions
  bool canCreateStudent(String role) => ['correspondent', 'administrator', 'accountant'].contains(role);
  bool canEditStudent(String role) => ['correspondent', 'administrator', 'accountant'].contains(role);
  bool canDeleteStudent(String role) => role == 'correspondent';

  IconData _getRoleIcon(String role) {
    switch (role.toLowerCase()) {
      case 'correspondent':
        return Icons.admin_panel_settings;
      case 'teacher':
        return Icons.school;
      case 'principal':
        return Icons.account_balance;
      case 'viceprincipal':
        return Icons.supervisor_account;
      case 'administrator':
        return Icons.settings;
      case 'accountant':
        return Icons.calculate;
      case 'parent':
        return Icons.family_restroom;
      default:
        return Icons.person;
    }
  }

  int get initialTab {
    final tabParam = Get.parameters['initialTab'];
    return tabParam != null ? int.tryParse(tabParam) ?? 0 : 0;
  }

  // Get the adjusted initial tab index based on available tabs
  int getAdjustedInitialTab(List<Map<String, dynamic>> tabs) {
    if (tabs.isEmpty) return 0;

    // If no specific tab requested, return 0
    if (initialTab == 0) return 0;

    // Try to find the requested tab in available tabs
    // For now, just ensure the index is within bounds
    return initialTab < tabs.length ? initialTab : 0;
  }

  // Define tab configurations with their permission requirements
  List<Map<String, dynamic>> get availableTabs {
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';

    final allTabs = [
      // Schools tab - API-based permission check
      if (ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/school/create') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/school/update') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/school/delete') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/school/updatelogo'))
        {'title': 'Schools', 'icon': Icons.school, 'builder': _buildSchoolsTab},

      // Classes tab - API-based permission check
      if (ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/class/create') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/class/update') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/class/delete'))
        {'title': 'Classes', 'icon': Icons.class_, 'builder': _buildClassesTab},

      // Sections tab - API-based permission check
      if (ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/section/create') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/section/update') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/section/delete'))
        {'title': 'Sections', 'icon': Icons.group, 'builder': _buildSectionsTab},

      // Students tab - API-based permission check
      if (ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/student/create') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/student/update') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/student/delete'))
        {'title': 'Students', 'icon': Icons.people, 'builder': _buildStudentsTab},

      // Users tab - Make visible for everyone who can create users
      if (ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/user/create'))
        {'title': 'Users', 'icon': Icons.person, 'builder': _buildUsersTab},

      // Teacher Assign tab - API-based permission check
      if (ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/teacher/assignments/manage'))
        {'title': 'Teachers', 'icon': Icons.assignment_ind, 'builder': _buildTeacherAssignmentTab},

      // Fee Structure tab - API-based permission check (show if user can view or save fee structure)
      if (ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/feestructure/set') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'GET /api/feestructure/getbyclass'))
        {'title': 'Fees', 'icon': Icons.payment, 'builder': _buildFeeStructureTab},

      // Attendance tab - API-based permission check
      if (ApiPermissions.hasApiAccess(currentUserRole, 'GET /api/attendance/sheet') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/attendance/mark') ||
          ApiPermissions.hasApiAccess(currentUserRole, 'GET /api/attendance/getallclass'))
        {'title': 'Attendance', 'icon': Icons.how_to_reg, 'builder': _buildAttendanceTab},
    ];

    return allTabs;
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.getAllSchools();
      _initializeSchoolForUser();
    });

    final tabs = availableTabs;

    // If no tabs available, show a message
    if (tabs.isEmpty) {
      return Scaffold(
        body: SafeArea(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF667eea), Color(0xFF764ba2)],
              ),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.lock_outline,
                    size: 80,
                    color: Colors.white.withOpacity(0.8),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'No Management Access',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No management options available for your role',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white.withOpacity(0.8),
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    final adjustedInitialTab = getAdjustedInitialTab(tabs);

    return DefaultTabController(
      length: tabs.length,
      initialIndex: adjustedInitialTab,
      child: Scaffold(
        backgroundColor: Colors.grey[50],
        body: SafeArea(
          child: Column(
            children: [
              // Custom App Bar with Gradient
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.topRight,
                    colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(24),
                    bottomRight: Radius.circular(24),
                  ),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.admin_panel_settings,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'School Management',
                                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Manage your institution efficiently',
                                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Colors.white.withOpacity(0.8),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Custom Tab Bar
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: TabBar(
                        isScrollable: true,
                        indicator: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        labelColor: const Color(0xFF667eea),
                        unselectedLabelColor: Colors.white.withOpacity(0.7),
                        labelStyle: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                        unselectedLabelStyle: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                        ),
                        tabs: tabs.map((tab) => Tab(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(tab['icon'] as IconData, size: 18),
                                const SizedBox(width: 8),
                                Text(tab['title'] as String),
                              ],
                            ),
                          ),
                        )).toList(),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
              // Tab Content
              Expanded(
                child: ResponsiveWrapper(
                  child: TabBarView(
                    children: tabs.map((tab) => (tab['builder'] as Widget Function())()).toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _buildFeeStructureTab() {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppTheme.primaryGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.payment, color: Colors.white, size: 24),
                  const SizedBox(width: 12),
                  const Text(
                    'Fee Structure Management',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Tab Bar
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: TabBar(
                indicator: BoxDecoration(
                  color: AppTheme.primaryBlue,
                  borderRadius: BorderRadius.circular(8),
                ),
                labelColor: Colors.white,
                unselectedLabelColor: AppTheme.primaryBlue,
                labelStyle: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
                tabs: const [
                  Tab(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add, size: 18),
                        SizedBox(width: 8),
                        Text('Set Fee Structure'),
                      ],
                    ),
                  ),
                  Tab(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.list, size: 18),
                        SizedBox(width: 8),
                        Text('All Fee Structures'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Tab Content
            Expanded(
              child: TabBarView(
                children: [
                  _FeeStructureTab(),
                  AllFeeStructuresTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceTab() {
    return _AttendanceTab();
  }

  Widget _buildSchoolsTab() {
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667eea)),
            ),
          );
        }
        
        return RefreshIndicator(
          onRefresh: controller.refreshSchools,
          color: const Color(0xFF667eea),
          child: controller.schools.isEmpty
              ? _buildEmptyState(
                  icon: Icons.school,
                  title: 'No Schools Found',
                  subtitle: 'Create your first school to get started',
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: controller.schools.length,
                  itemBuilder: (context, index) {
                    final school = controller.schools[index];
                    return _buildSchoolCard(school, currentUserRole, index);
                  },
                ),
        );
      }),
      floatingActionButton: ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/school/create')
          ? _buildFloatingActionButton(
              onPressed: () => Get.toNamed('/create-school'),
              icon: Icons.add,
              label: 'Add School',
            )
          : null,
    );
  }

  Widget _buildSchoolCard(School school, String currentUserRole, int index) {
    final gradients = [
      AppTheme.geographyGradient,
      AppTheme.mathGradient,
      AppTheme.biologyGradient,
      AppTheme.chemistryGradient,
    ];

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        gradient: gradients[index % 4],
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => controller.getSchool(school.id),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.school,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            school.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          if (school.schoolCode != null)
                            Text(
                              'Code: ${school.schoolCode}',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontSize: 14,
                              ),
                            ),
                        ],
                      ),
                    ),
                    PopupMenuButton<String>(
                      icon: const Icon(Icons.more_vert, color: Colors.white),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      itemBuilder: (context) => [
                        if (ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/school/update'))
                          const PopupMenuItem(
                            value: 'edit',
                            child: Row(
                              children: [
                                Icon(Icons.edit, size: 18),
                                SizedBox(width: 8),
                                Text('Edit'),
                              ],
                            ),
                          ),
                        if (ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/school/updatelogo'))
                          const PopupMenuItem(
                            value: 'logo',
                            child: Row(
                              children: [
                                Icon(Icons.image, size: 18),
                                SizedBox(width: 8),
                                Text('Update Logo'),
                              ],
                            ),
                          ),
                        if (ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/school/delete'))
                          const PopupMenuItem(
                            value: 'delete',
                            child: Row(
                              children: [
                                Icon(Icons.delete, size: 18, color: Colors.red),
                                SizedBox(width: 8),
                                Text('Delete', style: TextStyle(color: Colors.red)),
                              ],
                            ),
                          ),
                      ],
                      onSelected: (value) {
                        if (value == 'edit') {
                          controller.showEditSchoolDialog(school);
                        } else if (value == 'logo') {
                          controller.pickAndUploadLogo(school.id);
                        } else if (value == 'delete') {
                          _showDeleteConfirmation(school);
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _buildSchoolInfoGrid(school),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSchoolInfoGrid(School school) {
    final infoItems = [
      if (school.email != null) {'icon': Icons.email, 'label': 'Email', 'value': school.email!},
      if (school.phoneNo != null) {'icon': Icons.phone, 'label': 'Phone', 'value': school.phoneNo!},
      if (school.currentAcademicYear != null) {'icon': Icons.calendar_today, 'label': 'Academic Year', 'value': school.currentAcademicYear!},
      if (school.address != null) {'icon': Icons.location_on, 'label': 'Address', 'value': school.address!},
    ];

    return Wrap(
      spacing: 16,
      runSpacing: 12,
      children: infoItems.map((item) => _buildInfoChip(
        item['icon'] as IconData,
        item['label'] as String,
        item['value'] as String,
      )).toList(),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Colors.white),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              size: 64,
              color: Colors.grey[400],
            ),
          ),
          const SizedBox(height: 24),
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingActionButton({
    required VoidCallback onPressed,
    required IconData icon,
    required String label,
  }) {
    return FloatingActionButton.extended(
      onPressed: onPressed,
      backgroundColor: const Color(0xFF667eea),
      foregroundColor: Colors.white,
      elevation: 8,
      icon: Icon(icon),
      label: Text(label),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }

  Widget _buildClassesTab() {
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (controller.schools.isEmpty) {
        controller.getAllSchools();
      }
    });

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          // School Selector
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Obx(() {
              if (controller.schools.isEmpty) {
                return const Center(child: CircularProgressIndicator());
              }

              final selectedSchool = controller.schools.contains(controller.selectedSchool.value)
                  ? controller.selectedSchool.value
                  : null;

              return DropdownButtonFormField<School>(
                decoration: InputDecoration(
                  hintText: 'Choose School',
                  hintStyle: TextStyle(color: Colors.grey.shade600),
                  prefixIcon: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 20),
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                ),
                dropdownColor: Colors.white,
                menuMaxHeight: 300,
                borderRadius: BorderRadius.circular(12),
                icon: Container(
                  margin: const EdgeInsets.only(right: 12),
                  child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
                ),
                style: TextStyle(
                  color: Colors.grey.shade800,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
                value: selectedSchool,
                selectedItemBuilder: (context) {
                  return controller.schools.map((school) {
                    return Text(
                      school.name,
                      style: TextStyle(
                        color: Colors.grey.shade800,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    );
                  }).toList();
                },
                items: controller.schools.map((school) {
                  return DropdownMenuItem<School>(
                    value: school,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryBlue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 16),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              school.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (School? school) {
                  controller.selectedSchool.value = school;
                  if (school != null) {
                    controller.getAllClasses(school.id);
                  } else {
                    controller.classes.clear();
                  }
                },
              );
            }),
          ),

          // Classes List
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator());
              }

              if (controller.classes.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.class_,
                  title: 'No Classes Found',
                  subtitle: 'Add classes to organize your students',
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: controller.classes.length,
                itemBuilder: (context, index) {
                  final schoolClass = controller.classes[index];
                  return _buildClassCard(schoolClass, currentUserRole, index);
                },
              );
            }),
          ),
        ],
      ),
      floatingActionButton: ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/class/create')
          ? _buildFloatingActionButton(
              onPressed: _showCreateClassDialog,
              icon: Icons.add,
              label: 'Add Class',
            )
          : null,
    );
  }

  Widget _buildClassCard(SchoolClass schoolClass, String currentUserRole, int index) {
    final colors = [
      Colors.blue,
      Colors.green,
      Colors.orange,
      Colors.purple,
    ];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () {
            // Handle class tap
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: colors[index % 4].withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.class_,
                    color: colors[index % 4],
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        schoolClass.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Order: ${schoolClass.order}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                if (schoolClass.hasSections)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'Has Sections',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                const SizedBox(width: 8),
                PopupMenuButton<String>(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  itemBuilder: (context) => [
                    if (ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/class/update'))
                      const PopupMenuItem(
                        value: 'edit',
                        child: Row(
                          children: [
                            Icon(Icons.edit, size: 18),
                            SizedBox(width: 8),
                            Text('Edit'),
                          ],
                        ),
                      ),
                    if (ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/class/delete'))
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, size: 18, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Delete', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                  ],
                  onSelected: (value) {
                    if (value == 'edit') {
                      _showEditClassDialog(schoolClass);
                    } else if (value == 'delete') {
                      controller.deleteClass(schoolClass.id).then((_) {
                        if (controller.selectedSchool.value != null) {
                          controller.getAllClasses(controller.selectedSchool.value!.id);
                        }
                      });
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionsTab() {
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';

    // Initialize schools when sections tab is accessed
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (controller.schools.isEmpty) {
        controller.getAllSchools();
      }
    });

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          // School selector with modern design
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: AppTheme.mathSoftGradient,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: DropdownButtonFormField<School>(
              decoration: InputDecoration(
                hintText: 'Choose School',
                hintStyle: TextStyle(color: Colors.grey.shade600),
                prefixIcon: Container(
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 20),
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
              dropdownColor: Colors.white,
              menuMaxHeight: 300,
              borderRadius: BorderRadius.circular(12),
              icon: Container(
                margin: const EdgeInsets.only(right: 12),
                child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
              ),
              style: TextStyle(
                color: Colors.grey.shade800,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
              value: controller.selectedSchool.value,
              selectedItemBuilder: (context) {
                return controller.schools.map((school) {
                  return Text(
                    school.name,
                    style: TextStyle(
                      color: Colors.grey.shade800,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                  );
                }).toList();
              },
              items: controller.schools.isEmpty ? [] : controller.schools.map<DropdownMenuItem<School>>((school) {
                return DropdownMenuItem<School>(
                  value: school,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryBlue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 16),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          school.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
              onChanged: (School? school) {
                controller.selectedSchool.value = school;
                if (school != null) {
                  controller.getAllSections(schoolId: school.id);
                }
              },
            ),
          ),
          
          // Sections list with modern cards
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator(color: Color(0xFF667eea)));
              }
              
              if (controller.sections.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.group,
                  title: 'No Sections Found',
                  subtitle: 'Add sections to organize classes better',
                );
              }
              
              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: controller.sections.length,
                itemBuilder: (context, index) {
                  final section = controller.sections[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => _showSectionDetailsDialog(context, section),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: AppTheme.chemistryYellow.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(Icons.group, color: AppTheme.chemistryYellow, size: 24),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      section.name,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Class: ${section.className ?? "N/A"}',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey[600],
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Text(
                                      'Room: ${section.roomNumber ?? "N/A"}',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey[600],
                                      ),
                                    ),
                                    if (section.classTeachers != null && section.classTeachers!.isNotEmpty)
                                      Text(
                                        'Teachers: ${section.classTeachers!.map((t) => t['userName'] ?? 'Unknown').join(', ')}',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.blue[600],
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                  ],
                                ),
                              ),
                              PopupMenuButton<String>(
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                itemBuilder: (context) => [
                                  const PopupMenuItem(
                                    value: 'view',
                                    child: Row(
                                      children: [
                                        Icon(Icons.visibility, size: 18),
                                        SizedBox(width: 8),
                                        Text('View Details'),
                                      ],
                                    ),
                                  ),
                                  if (ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/section/update'))
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Row(
                                        children: [
                                          Icon(Icons.edit, size: 18),
                                          SizedBox(width: 8),
                                          Text('Edit'),
                                        ],
                                      ),
                                    ),
                                  if (ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/section/delete'))
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Row(
                                        children: [
                                          Icon(Icons.delete, size: 18, color: Colors.red),
                                          SizedBox(width: 8),
                                          Text('Delete', style: TextStyle(color: Colors.red)),
                                        ],
                                      ),
                                    ),
                                ],
                                onSelected: (value) {
                                  if (value == 'view') {
                                    _showSectionDetailsDialog(context, section);
                                  } else if (value == 'edit') {
                                    _showEditSectionDialog(section);
                                  } else if (value == 'delete') {
                                    controller.deleteSection(section.id).then((_) {
                                      if (controller.selectedSchool.value != null) {
                                        controller.getAllSections(schoolId: controller.selectedSchool.value!.id);
                                      }
                                    });
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
      floatingActionButton: ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/section/create')
          ? _buildFloatingActionButton(
              onPressed: () => _showCreateSectionDialog(),
              icon: Icons.add,
              label: 'Add Section',
            )
          : null,
    );
  }

  Widget _buildStudentsTab() {
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          // School selector
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Obx(() => DropdownButtonFormField<School>(
              decoration: InputDecoration(
                hintText: 'Choose School',
                hintStyle: TextStyle(color: Colors.grey.shade600),
                prefixIcon: Container(
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 20),
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
              dropdownColor: Colors.white,
              menuMaxHeight: 300,
              borderRadius: BorderRadius.circular(12),
              icon: Container(
                margin: const EdgeInsets.only(right: 12),
                child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
              ),
              style: TextStyle(
                color: Colors.grey.shade800,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
              value: controller.selectedSchool.value,
              selectedItemBuilder: (context) {
                return controller.schools.map((school) {
                  return Text(
                    school.name,
                    style: TextStyle(
                      color: Colors.grey.shade800,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                  );
                }).toList();
              },
              items: controller.schools.isEmpty ? [] : controller.schools.map<DropdownMenuItem<School>>((school) {
                return DropdownMenuItem<School>(
                  value: school,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryBlue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 16),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          school.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
              onChanged: (School? school) {
                controller.selectedSchool.value = school;
                if (school != null) {
                  controller.getAllStudents(schoolId: school.id);
                  
                }
              },
            )),
          ),
          
          // Students list
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const Center(child: CircularProgressIndicator(color: Color(0xFF667eea)));
              }
              
              if (controller.students.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.people,
                  title: 'No Students Found',
                  subtitle: 'Add students to get started',
                );
              }
              
              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: controller.students.length,
                itemBuilder: (context, index) {
                  final student = controller.students[index];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      gradient: AppTheme.biologyGradient,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.primaryBlue.withOpacity(0.2),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(
                                  Icons.person,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Name: ${student.name ?? 'N/A'}',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Roll: ${student.rollNumber ?? 'N/A'}',
                                      style: const TextStyle(
                                        color: Colors.white70,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              PopupMenuButton<String>(
                                icon: const Icon(Icons.more_vert, color: Colors.white),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                itemBuilder: (context) => [
                                  const PopupMenuItem(
                                    value: 'details',
                                    child: Row(
                                      children: [
                                        Icon(Icons.visibility, size: 18),
                                        SizedBox(width: 8),
                                        Text('View Details'),
                                      ],
                                    ),
                                  ),
                                  const PopupMenuItem(
                                    value: 'edit',
                                    child: Row(
                                      children: [
                                        Icon(Icons.edit, size: 18),
                                        SizedBox(width: 8),
                                        Text('Edit'),
                                      ],
                                    ),
                                  ),
                                  const PopupMenuItem(
                                    value: 'delete',
                                    child: Row(
                                      children: [
                                        Icon(Icons.delete, size: 18, color: Colors.red),
                                        SizedBox(width: 8),
                                        Text('Delete', style: TextStyle(color: Colors.red)),
                                      ],
                                    ),
                                  ),
                                ],
                                onSelected: (value) {
                                  if (value == 'details') {
                                    Get.to(() => StudentIndividualDetailView(
                                      student: student,
                                      schoolId: controller.selectedSchool.value!.id,
                                    ))?.then((_) {
                                      if (controller.selectedSchool.value != null) {
                                        controller.getAllStudents(schoolId: controller.selectedSchool.value!.id);
                                      }
                                    });
                                  } else if (value == 'edit') {
                                    _showEditStudentDialog(student);
                                  } else if (value == 'delete') {
                                    _showDeleteStudentConfirmation(student);
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
      floatingActionButton: ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/student/create')
          ? _buildFloatingActionButton(
              onPressed: () => _showCreateStudentDialog(),
              icon: Icons.add,
              label: 'Add Student',
            )
          : null,
    );
  }

  Widget _buildUsersTab() {
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';
    final isReadOnly = !['correspondent'].contains(currentUserRole);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          // School selector - readonly for non-correspondent users
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: AppTheme.successGradient,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.school, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Text(
                      isReadOnly ? 'Your School' : 'Select School',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (isReadOnly)
                  // Show readonly school name for non-correspondent users
                  Obx(() {
                    final userSchoolId = authController.user.value?.schoolId;
                    final userSchool = controller.schools.firstWhereOrNull(
                      (school) => school.id == userSchoolId,
                    );
                    final schoolName = controller.selectedSchool.value?.name ?? userSchool?.name ?? 'Loading...';
                    
                    return Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppTheme.primaryBlue.withOpacity(0.05), AppTheme.primaryBlue.withOpacity(0.02)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.2), width: 1.5),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              gradient: AppTheme.primaryGradient,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.business, color: Colors.white, size: 16),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              schoolName,
                              style: TextStyle(
                                color: AppTheme.primaryText,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  })
                else
                  // Show dropdown for correspondent users
                  Obx(() => DropdownButtonFormField<School>(
                    decoration: InputDecoration(
                      hintText: 'Choose School',
                      hintStyle: TextStyle(color: Colors.grey.shade600),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryBlue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 20),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    ),
                    dropdownColor: Colors.white,
                    menuMaxHeight: 300,
                    borderRadius: BorderRadius.circular(12),
                    icon: Container(
                      margin: const EdgeInsets.only(right: 12),
                      child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
                    ),
                    style: TextStyle(
                      color: Colors.grey.shade800,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    value: controller.selectedSchool.value,
                    selectedItemBuilder: (context) {
                      return controller.schools.map((school) {
                        return Text(
                          school.name,
                          style: TextStyle(
                            color: Colors.grey.shade800,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        );
                      }).toList();
                    },
                    items: controller.schools
                        .map((school) => DropdownMenuItem<School>(
                              value: school,
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 8),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        color: AppTheme.primaryBlue.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 16),
                                    ),
                                    const SizedBox(width: 12),
                                    Text(
                                      school.name,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w500,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            ))
                        .toList(),
                    onChanged: (school) {
                      controller.selectedSchool.value = school;
                      if (school != null) {
                        userController.loadUsers(
                          schoolId: school.id,
                          role: userController.selectedRole.value,
                        );
                      }
                    },
                  )),
              ],
            ),
          ),

          // Role filter
          Container(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: DropdownButtonFormField<String>(
              decoration: InputDecoration(
                hintText: 'Filter by Role',
                hintStyle: TextStyle(color: Colors.grey.shade600),
                prefixIcon: Container(
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.filter_list, color: AppTheme.primaryBlue, size: 20),
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
              dropdownColor: Colors.white,
              menuMaxHeight: 300,
              borderRadius: BorderRadius.circular(12),
              icon: Container(
                margin: const EdgeInsets.only(right: 12),
                child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
              ),
              style: TextStyle(
                color: Colors.grey.shade800,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
              value: userController.selectedRole.value,
              selectedItemBuilder: (context) {
                return const [
                  'all',
                  'correspondent',
                  'teacher',
                  'principal',
                  'viceprincipal',
                  'administrator',
                  'accountant',
                  'parent'
                ].map((r) {
                  return Text(
                    r.toUpperCase(),
                    style: TextStyle(
                      color: Colors.grey.shade800,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                  );
                }).toList();
              },
              items: const [
                'all',
                'correspondent',
                'teacher',
                'principal',
                'viceprincipal',
                'administrator',
                'accountant',
                'parent'
              ].map((r) {
                return DropdownMenuItem<String>(
                  value: r,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryBlue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Icon(_getRoleIcon(r), color: AppTheme.primaryBlue, size: 16),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          r.toUpperCase(),
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
              onChanged: (role) {
                if (role != null) {
                  userController.selectedRole.value = role;
                  final schoolId = controller.selectedSchool.value?.id ??
                      authController.user.value?.schoolId;
                  if (schoolId != null) {
                    userController.loadUsers(
                      schoolId: schoolId,
                      role: role,
                    );
                  }
                }
              },
            ),
          ),

          // User list
          Expanded(
            child: Obx(() {
              if (userController.isLoading.value) {
                return const Center(child: CircularProgressIndicator(color: Color(0xFF667eea)));
              }

              if (userController.users.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.person,
                  title: 'No Users Found',
                  subtitle: 'Add users to manage your school',
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: userController.users.length,
                itemBuilder: (context, index) {
                  final user = userController.users[index];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      gradient: AppTheme.successGradient,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () {
                          Get.to(() => UserDetailView(user: user));
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(
                                  Icons.person,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      user['userName'] ?? 'Unknown',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Role: ${user['role'] ?? 'No Role'}',
                                      style: const TextStyle(color: Colors.white70, fontSize: 14),
                                    ),
                                    Text(
                                      'Email: ${user['email'] ?? 'N/A'}',
                                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                                    ),
                                  ],
                                ),
                              ),
                              // Assign role button - only show for correspondent and administrator
                              if (user['role'] == null &&
                                  ['correspondent', 'administrator'].contains(currentUserRole) &&
                                  ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/user/assignrole'))
                                SizedBox(
                                  width: 100,
                                  child: Container(
                                    margin: const EdgeInsets.only(right: 8),
                                    child: ElevatedButton(
                                      onPressed: () => _showAssignRoleDialog(user),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.white,
                                        foregroundColor: AppTheme.successGreen,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                      ),
                                      child: const Text('Assign Role', style: TextStyle(fontSize: 12)),
                                    ),
                                  ),
                                ),
                              // Menu
                              PopupMenuButton<String>(
                                icon: const Icon(Icons.more_vert, color: Colors.white),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                itemBuilder: (context) => [
                                  if (ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/user/update') && currentUserRole != 'teacher')
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Row(
                                        children: [
                                          Icon(Icons.edit, size: 18),
                                          SizedBox(width: 8),
                                          Text('Edit'),
                                        ],
                                      ),
                                    ),
                                  if (ApiPermissions.hasApiAccess(currentUserRole, 'PUT /api/user/assignrole') &&
                                      ['correspondent', 'administrator'].contains(currentUserRole))
                                    const PopupMenuItem(
                                      value: 'role',
                                      child: Row(
                                        children: [
                                          Icon(Icons.admin_panel_settings, size: 18),
                                          SizedBox(width: 8),
                                          Text('Change Role'),
                                        ],
                                      ),
                                    ),
                                  if (ApiPermissions.hasApiAccess(currentUserRole, 'DELETE /api/user/delete'))
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Row(
                                        children: [
                                          Icon(Icons.delete, size: 18, color: Colors.red),
                                          SizedBox(width: 8),
                                          Text('Delete', style: TextStyle(color: Colors.red)),
                                        ],
                                      ),
                                    ),
                                ],
                                onSelected: (value) {
                                  if (value == 'edit') {
                                    _showEditUserDialog(user);
                                  } else if (value == 'role') {
                                    _showAssignRoleDialog(user);
                                  } else if (value == 'delete') {
                                    _showDeleteUserDialog(user);
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
          ),
        ],
      ),
      floatingActionButton: ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/user/create')
          ? _buildFloatingActionButton(
              onPressed: _showCreateUserDialog,
              icon: Icons.person_add,
              label: 'Add User',
            )
          : null,
    );
  }

  Widget _buildTeacherAssignmentTab() {
    return TeacherAssignmentView();
  }

  Widget _buildAttendanceCard(String title, String percentage, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(
            percentage,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildComingSoonTab(String title, IconData icon) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF8F9FA), Color(0xFFE9ECEF)],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFF667eea).withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 64,
                color: const Color(0xFF667eea),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              '$title Management',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF667eea),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Enhanced UI coming soon...',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Dialog methods remain the same but with improved styling
  void _showDeleteConfirmation(School school) {
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.warning, color: Colors.red),
            SizedBox(width: 8),
            Text('Delete School'),
          ],
        ),
        content: Text('Are you sure you want to delete ${school.name}?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              controller.deleteSchool(school.id);
              Get.back();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showCreateClassDialog() {
    if (controller.selectedSchool.value == null) {
      Get.snackbar(
        'Error',
        'Please select a school first',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
      return;
    }

    final nameController = TextEditingController();
    final orderController = TextEditingController();
    bool hasSections = false;

    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Create Class'),
        content: StatefulBuilder(
          builder: (context, setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    labelText: 'Class Name',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: orderController,
                  decoration: InputDecoration(
                    labelText: 'Order',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 16),
                CheckboxListTile(
                  title: const Text('Has Sections'),
                  value: hasSections,
                  onChanged: (value) {
                    setState(() {
                      hasSections = value ?? false;
                    });
                  },
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              controller.createClass(controller.selectedSchool.value!.id, {
                'name': nameController.text,
                'order': int.tryParse(orderController.text) ?? 0,
                'hasSections': hasSections,
              });
              Get.back();
              if (controller.selectedSchool.value != null) {
                controller.getAllClasses(controller.selectedSchool.value!.id);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _showEditClassDialog(SchoolClass schoolClass) {
    final nameController = TextEditingController(text: schoolClass.name);
    final orderController = TextEditingController(text: schoolClass.order.toString());
    bool hasSections = schoolClass.hasSections;
    final isLoading = false.obs;

    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Edit Class'),
        content: StatefulBuilder(
          builder: (context, setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    labelText: 'Class Name',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: orderController,
                  decoration: InputDecoration(
                    labelText: 'Order',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 16),
                CheckboxListTile(
                  title: const Text('Has Sections'),
                  value: hasSections,
                  onChanged: (value) {
                    setState(() {
                      hasSections = value ?? false;
                    });
                  },
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          Obx(() => ElevatedButton(
            onPressed: isLoading.value ? null : () async {

              isLoading.value = true;
              try {
                await controller.updateClass(schoolClass.id, {
                  'name': nameController.text,
                  'order': int.tryParse(orderController.text) ?? 0,
                  'hasSections': hasSections,
                });
                
                Get.back();
                if (controller.selectedSchool.value != null) {
                  controller.getAllClasses(controller.selectedSchool.value!.id);
                }
              } catch (e) {
                
              } finally {
                isLoading.value = false;
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: isLoading.value
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Text('Update'),
          )),
        ],
      ),
    );
  }

  void _showCreateSectionDialog() {
    if (controller.selectedSchool.value == null) {
      Get.snackbar('Error', 'Please select a school first');
      return;
    }

    final nameController = TextEditingController();
    final roomController = TextEditingController();
    final capacityController = TextEditingController();
    SchoolClass? selectedClass;

    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Create Section'),
        content: StatefulBuilder(
          builder: (context, setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<SchoolClass>(
                  decoration: InputDecoration(
                    hintText: 'Choose Class',
                    hintStyle: TextStyle(color: Colors.grey.shade600),
                    prefixIcon: Container(
                      margin: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryBlue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(Icons.class_, color: AppTheme.primaryBlue, size: 20),
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  ),
                  dropdownColor: Colors.white,
                  menuMaxHeight: 300,
                  borderRadius: BorderRadius.circular(12),
                  icon: Container(
                    margin: const EdgeInsets.only(right: 12),
                    child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
                  ),
                  style: TextStyle(
                    color: Colors.grey.shade800,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                  value: selectedClass,
                  selectedItemBuilder: (context) {
                    return controller.classes.map((cls) {
                      return Text(
                        cls.name,
                        style: TextStyle(
                          color: Colors.grey.shade800,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        overflow: TextOverflow.ellipsis,
                      );
                    }).toList();
                  },
                  items: controller.classes.map<DropdownMenuItem<SchoolClass>>((cls) {
                    return DropdownMenuItem<SchoolClass>(
                      value: cls,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryBlue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Icon(Icons.class_, color: AppTheme.primaryBlue, size: 16),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              cls.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                  onChanged: (SchoolClass? value) {
                    setState(() {
                      selectedClass = value;
                    });
                    if (value != null) {
                      controller.getAllSections(classId: value.id, schoolId: controller.selectedSchool.value!.id);
                    }
                  },
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    labelText: 'Section Name',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: roomController,
                  decoration: InputDecoration(
                    labelText: 'Room Number',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: capacityController,
                  decoration: InputDecoration(
                    labelText: 'Capacity',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  keyboardType: TextInputType.number,
                ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (selectedClass != null) {
                controller.createSection({
                  'schoolId': controller.selectedSchool.value!.id,
                  'classId': selectedClass!.id,
                  'name': nameController.text,
                  'roomNumber': roomController.text,
                  'capacity': int.tryParse(capacityController.text),
                });
                Get.back();
                controller.getAllSections(schoolId: controller.selectedSchool.value!.id);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _showEditSectionDialog(Section section) {
    final nameController = TextEditingController(text: section.name);
    final roomController = TextEditingController(text: section.roomNumber);
    final capacityController = TextEditingController(text: section.capacity?.toString());
    final isLoading = false.obs;

    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Edit Section'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: 'Section Name',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: roomController,
              decoration: InputDecoration(
                labelText: 'Room Number',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: capacityController,
              decoration: InputDecoration(
                labelText: 'Capacity',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          Obx(() => ElevatedButton(
            onPressed: isLoading.value ? null : () async {

              isLoading.value = true;
              try {
                await controller.updateSection(section.id, {
                  'name': nameController.text,
                  'roomNumber': roomController.text,
                  'capacity': int.tryParse(capacityController.text),
                });
                
                Get.back();
                if (controller.selectedSchool.value != null) {
                  controller.getAllSections(schoolId: controller.selectedSchool.value!.id);
                }
              } catch (e) {
                
              } finally {
                isLoading.value = false;
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: isLoading.value
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Text('Update'),
          )),
        ],
      ),
    );
  }

  void _showCreateStudentDialog() {
    if (controller.selectedSchool.value == null) {
      Get.snackbar('Error', 'Please select a school first');
      return;
    }
    Get.dialog(
      StudentFormDialog(
        schoolId: controller.selectedSchool.value!.id,
        isEdit: false,
      ),
    );
  }

  void _showEditStudentDialog(Student student) {
    Get.dialog(
      StudentFormDialog(
        student: student,
        schoolId: student.schoolId ?? controller.selectedSchool.value!.id,
        isEdit: true,
      ),
    );
  }

  void _showDeleteStudentConfirmation(Student student) {
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete Student'),
        content: Text('Are you sure you want to delete ${student.name ?? 'this student'}?'),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              controller.deleteStudent(student.id);
              Get.back();
              if (controller.selectedSchool.value != null) {
                controller.getAllStudents(schoolId: controller.selectedSchool.value!.id);
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showCreateUserDialog() {
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';
    final isCorrespondent = currentUserRole == 'correspondent';
    
    final emailController = TextEditingController();
    final userNameController = TextEditingController();
    final passwordController = TextEditingController();
    final phoneController = TextEditingController();
    String? selectedSchoolCode;

    // Load schools only once
    controller.getAllSchools();
    
    // For non-correspondent users, selectedSchoolCode will be set automatically in StatefulBuilder
    if (!isCorrespondent) {
      // Trigger schools loading
      controller.getAllSchools();
    }

    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: const Text('Create User'),

        content: StatefulBuilder(
          builder: (context, setState) {
            // For non-correspondent users, auto-select their school when schools load
            if (!isCorrespondent && selectedSchoolCode == null && controller.schools.isNotEmpty) {
              final userSchoolId = authController.user.value?.schoolId;
              final userSchool = controller.schools.firstWhereOrNull(
                (school) => school.id == userSchoolId,
              );
              if (userSchool != null && userSchool.schoolCode != null) {
                selectedSchoolCode = userSchool.schoolCode;
              }
            }
            
            return SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Email
                  TextField(
                    controller: emailController,
                    decoration: InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // User Name
                  TextField(
                    controller: userNameController,
                    decoration: InputDecoration(
                      labelText: 'User Name',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Password
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Phone
                  TextField(
                    controller: phoneController,
                    decoration: InputDecoration(
                      labelText: 'Phone',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // School Selection - Dropdown for correspondent, readonly for others
                  if (isCorrespondent)
                    // School Dropdown for correspondent
                    DropdownButtonFormField<String>(
                      isExpanded: true,
                      isDense: true,
                      value: selectedSchoolCode,
                      decoration: InputDecoration(
                        hintText: 'Choose School',
                        hintStyle: TextStyle(color: Colors.grey.shade600),
                        prefixIcon: Icon(
                          Icons.school,
                          color: AppTheme.primaryBlue,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 12,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      icon: Icon(
                        Icons.keyboard_arrow_down,
                        color: AppTheme.primaryBlue,
                      ),
                      dropdownColor: Colors.white,
                      menuMaxHeight: 300,
                      selectedItemBuilder: (context) {
                        return controller.schools.map((school) {
                          return Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              '${school.name} (${school.schoolCode})',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.grey.shade800,
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          );
                        }).toList();
                      },
                      items: controller.schools.map((school) {
                        return DropdownMenuItem<String>(
                          value: school.schoolCode,
                          child: Row(
                            children: [
                              Icon(
                                Icons.school,
                                size: 16,
                                color: AppTheme.primaryBlue,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  '${school.name} (${school.schoolCode})',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() => selectedSchoolCode = value);
                      },
                    )
                  else
                    // Readonly school display for non-correspondent users
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.grey.shade50,
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.school,
                            color: AppTheme.primaryBlue,
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              controller.schools.firstWhereOrNull(
                                (school) => school.schoolCode == selectedSchoolCode,
                              )?.name ?? 'Loading...',
                              style: TextStyle(
                                color: Colors.grey.shade800,
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            );
          },
        ),

        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),

          Obx(
                () => ElevatedButton(
              onPressed: userController.isLoading.value
                  ? null
                  : () async {
                if (selectedSchoolCode == null) {
                  Get.snackbar(
                    'Error',
                    'Please select a school',
                  );
                  return;
                }

                await userController.createUser(
                  email: emailController.text,
                  userName: userNameController.text,
                  password: passwordController.text,
                  phoneNo: phoneController.text,
                  schoolCode: selectedSchoolCode!,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF667eea),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: userController.isLoading.value
                  ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
                  : const Text('Create'),
            ),
          ),
        ],
      ),
    );
  }

  void _showAssignRoleDialog(Map<String, dynamic> user) {
    String selectedRole = user['role'] ?? 'correspondent';
    final validRoles = ['correspondent', 'teacher', 'principal', 'viceprincipal', 'administrator', 'parent', 'accountant'];
    
    if (!validRoles.contains(selectedRole)) {
      selectedRole = 'correspondent';
    }
    
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Assign Role to ${user['userName']}'),
        content: StatefulBuilder(
          builder: (context, setState) {
            return DropdownButtonFormField<String>(
              decoration: InputDecoration(
                hintText: 'Choose Role',
                hintStyle: TextStyle(color: Colors.grey.shade600),
                prefixIcon: Container(
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.admin_panel_settings, color: AppTheme.primaryBlue, size: 20),
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              ),
              dropdownColor: Colors.white,
              menuMaxHeight: 300,
              borderRadius: BorderRadius.circular(12),
              icon: Container(
                margin: const EdgeInsets.only(right: 12),
                child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
              ),
              style: TextStyle(
                color: Colors.grey.shade800,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
              value: validRoles.contains(selectedRole) ? selectedRole : 'correspondent',
              selectedItemBuilder: (context) {
                return validRoles.map((role) {
                  return Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      color: Colors.grey.shade800,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                  );
                }).toList();
              },
              items: validRoles.map((role) {
                return DropdownMenuItem<String>(
                  value: role,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryBlue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Icon(_getRoleIcon(role), color: AppTheme.primaryBlue, size: 16),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            role.toUpperCase(),
                            style: const TextStyle(
                              fontWeight: FontWeight.w500,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
              onChanged: (role) {
                if (role != null) setState(() => selectedRole = role);
              },
            );
          },
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              userController.assignRole(user['_id'], selectedRole);
              Get.back();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Assign'),
          ),
        ],
      ),
    );
  }

  void _showEditUserDialog(Map<String, dynamic> user) {
    final emailController = TextEditingController(text: user['email']);
    final userNameController = TextEditingController(text: user['userName']);
    final phoneController = TextEditingController(text: user['phoneNo']);
    final isLoading = false.obs;

    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Edit User: ${user['userName']}'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: userNameController,
                decoration: InputDecoration(
                  labelText: 'User Name',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: phoneController,
                decoration: InputDecoration(
                  labelText: 'Phone',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
          Obx(() => ElevatedButton(
            onPressed: isLoading.value ? null : () async {

              isLoading.value = true;
              try {
                await userController.updateUser(
                  userId: user['_id'],
                  email: emailController.text,
                  userName: userNameController.text,
                  phoneNo: phoneController.text,
                );

                // Close dialog first
                Get.back();
                
                // Show success message
                Get.snackbar(
                  'Success', 
                  'User updated successfully',
                  backgroundColor: Colors.green,
                  colorText: Colors.white,
                  duration: const Duration(seconds: 3),
                  snackPosition: SnackPosition.TOP,
                );
                
                // Refresh the user list
                final schoolId = controller.selectedSchool.value?.id ?? Get.find<AuthController>().user.value?.schoolId;
                if (schoolId != null) {
                  await userController.loadUsers(schoolId: schoolId, role: userController.selectedRole.value);
                }
                
                // If the updated user is the current user, refresh auth data
                final currentUserId = Get.find<AuthController>().user.value?.id;
                if (currentUserId == user['_id']) {
                  await Get.find<AuthController>().handleUserUpdateSuccess();
                }

              } catch (e) {
                
                Get.back();
                Get.snackbar(
                  'Error', 
                  'Failed to update user}',
                  backgroundColor: Colors.red,
                  colorText: Colors.white,
                  duration: const Duration(seconds: 3),
                  snackPosition: SnackPosition.TOP,
                );
              } finally {
                isLoading.value = false;
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: isLoading.value
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Text('Update'),
          )),
        ],
      ),
    );
  }

  void _showDeleteUserDialog(Map<String, dynamic> user) {
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete User'),
        content: Text('Are you sure you want to delete ${user['userName']}?'),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
          Obx(() => ElevatedButton(
            onPressed: userController.isLoading.value ? null : () async {
              await userController.deleteUser(user['_id']);
              Get.back();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: userController.isLoading.value
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Text('Delete'),
          )),
        ],
      ),
    );
  void _showFeeStructureDialog(SchoolClass schoolClass) {
    final feeController = Get.put(FeeStructureController());
    final amountController = TextEditingController();
    final descriptionController = TextEditingController();

    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Fee Structure - ${schoolClass.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              decoration: InputDecoration(
                labelText: 'Fee Amount',
                prefixText: '₹',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(
                labelText: 'Description',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              maxLines: 2,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (amountController.text.isNotEmpty) {
                await feeController.setFeeStructure(
                  schoolId: controller.selectedSchool.value!.id,
                  classId: schoolClass.id,
                  feeHead: {
                    'amount': double.tryParse(amountController.text) ?? 0,
                    'description': descriptionController.text,
                  },
                );
                Get.back();
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF667eea),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
}}

class _AttendanceTab extends StatefulWidget {
  @override
  State<_AttendanceTab> createState() => _AttendanceTabState();
}

class _AttendanceTabState extends State<_AttendanceTab> {
  final attendanceController = Get.put(old_attendance.AttendanceController());
  final schoolController = Get.find<SchoolController>();
  final authController = Get.find<AuthController>();

  // Permission-based properties
  bool get canMarkAttendance => ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/attendance/mark');
  bool get canViewAttendance => ApiPermissions.hasApiAccess(currentUserRole, 'GET /api/attendance/sheet');
  String get currentUserRole => authController.user.value?.role?.toLowerCase() ?? '';

  bool isHistoryMode = false;
  bool _isFiltersExpanded = true;
  DateTime selectedDate = DateTime.now();
  DateTime startDate = DateTime.now().subtract(const Duration(days: 30));
  DateTime endDate = DateTime.now();

  final TextEditingController _startYearController = TextEditingController(text: "2025");
  final TextEditingController _endYearController = TextEditingController(text: "2026");

  List<Map<String, dynamic>> attendanceRecords = [];
  List<Map<String, dynamic>> historyRecords = [];
  SchoolClass? selectedClass;

  String get academicYear => "${_startYearController.text}-${_endYearController.text}";

  @override
  void initState() {
    super.initState();
    // Set initial mode based on permissions
    // If user can mark attendance, start with Mark Daily mode
    // If user can only view, start with History mode
    isHistoryMode = !canMarkAttendance;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final school = schoolController.selectedSchool.value;
      if (school != null) {
        _onSchoolChanged(school);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;
    
    return SafeArea(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.purple.shade50, Colors.indigo.shade50],
          ),
        ),
        child: Column(
          children: [
            // Header
            Padding(
              padding: EdgeInsets.all(isTablet ? 24 : 16),
              child: _buildHeader(isTablet),
            ),
            
            // Scrollable Content
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: isTablet ? 24 : 16),
                child: Column(
                  children: [
                    // Mode Toggle
                    _buildModeToggle(),
                    const SizedBox(height: 16),
                    
                    // Collapsible Selectors
                    _buildAttendanceSelectors(isLandscape, isTablet),
                    const SizedBox(height: 16),
                    
                    // Summary Cards (for daily mode)
                    if (!isHistoryMode && attendanceRecords.isNotEmpty)
                      _buildCollapsibleSummary(isLandscape, isTablet),
                    
                    const SizedBox(height: 16),
                    
                    // Content Area
                    SizedBox(
                      height: 400,
                      child: _buildContentArea(isTablet),
                    ),

                    const SizedBox(height: 16),

                    // Read-only indicator for users who can view but not mark attendance
                    // if (!isHistoryMode && canViewAttendance && !canMarkAttendance)
                    //   Container(
                    //     width: double.infinity,
                    //     padding: const EdgeInsets.all(16),
                    //     decoration: BoxDecoration(
                    //       color: Colors.orange.shade50,
                    //       borderRadius: BorderRadius.circular(12),
                    //       border: Border.all(color: Colors.orange.shade200),
                    //     ),
                    //     child: Row(
                    //       children: [
                    //         Icon(
                    //           Icons.visibility,
                    //           color: Colors.orange.shade600,
                    //           size: 20,
                    //         ),
                    //         const SizedBox(width: 12),
                    //
                    //       ],
                    //     ),
                    //   ),

                    // Action Button - only show for users who can mark attendance
                    if (!isHistoryMode && attendanceRecords.isNotEmpty && canMarkAttendance)
                      _buildSaveButton(),
                    
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(bool isTablet) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.purple.shade600, Colors.indigo.shade600],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.purple.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.how_to_reg,
              color: Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Attendance Management',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isTablet ? 24 : 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Track and manage student attendance',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.8),
                    fontSize: isTablet ? 16 : 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeToggle() {
    // If user can only view attendance (not mark), show only History tab
    if (!canMarkAttendance && canViewAttendance) {
      return Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(
                Icons.history,
                color: Colors.purple.shade600,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Attendance History',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.purple.shade600,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.purple.shade100,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'View Only',
                  style: TextStyle(
                    color: Colors.purple.shade700,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    // If user can mark attendance, show both tabs
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: SegmentedButton<bool>(
          segments: const [
            ButtonSegment(
              value: false,
              label: Text('Mark Daily'),
              icon: Icon(Icons.today, size: 18),
            ),
            ButtonSegment(
              value: true,
              label: Text('History'),
              icon: Icon(Icons.history, size: 18),
            ),
          ],
          selected: {isHistoryMode},
          onSelectionChanged: (v) {
            if (mounted) {
              setState(() => isHistoryMode = v.first);
              _onFilterChanged();
            }
          },
          style: SegmentedButton.styleFrom(
            selectedBackgroundColor: Colors.purple.shade100,
            selectedForegroundColor: Colors.purple.shade700,
          ),
        ),
      ),
    );
  }

  Widget _buildAttendanceSelectors(bool isLandscape, bool isTablet) {
    return Obx(() {
      final hasSelections = schoolController.selectedSchool.value != null && selectedClass != null;
      final isExpanded = !hasSelections || _isFiltersExpanded;
      
      return AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: isExpanded ? null : 60,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: isExpanded
            ? _buildFullAttendanceSelectors(isLandscape, isTablet)
            : _buildCompactAttendanceSelectors(),
      );
    });
  }

  Widget _buildCompactAttendanceSelectors() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(Icons.school, color: Colors.purple.shade600, size: 18),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              schoolController.selectedSchool.value?.name ?? '',
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 12),
          Icon(Icons.class_, color: Colors.purple.shade600, size: 18),
          const SizedBox(width: 6),
          Text(
            selectedClass?.name ?? '',
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
          ),
          const Spacer(),
          IconButton(
            onPressed: () {
              if (mounted) {
                setState(() {
                  _isFiltersExpanded = true;
                });
              }
            },
            icon: const Icon(Icons.expand_more, size: 18),
            tooltip: 'Expand Filters',
          ),
        ],
      ),
    );
  }

  Widget _buildFullAttendanceSelectors(bool isLandscape, bool isTablet) {
    return Padding(
      padding: EdgeInsets.all(isTablet ? 20 : 16),
      child: Column(
        children: [
          // Header with collapse button
          Row(
            children: [
              Icon(Icons.filter_list, color: Colors.purple.shade600, size: 20),
              const SizedBox(width: 8),
              Text(
                'Filters',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: isTablet ? 18 : 16,
                  color: Colors.purple.shade600,
                ),
              ),
              const Spacer(),
              if (schoolController.selectedSchool.value != null && selectedClass != null)
                IconButton(
                  onPressed: () {
                    if (mounted) {
                      setState(() {
                        _isFiltersExpanded = false;
                      });
                    }
                  },
                  icon: const Icon(Icons.expand_less, size: 20),
                  tooltip: 'Collapse Filters',
                ),
            ],
          ),
          const SizedBox(height: 16),
          
          // School and Class Selection
          isLandscape && isTablet
              ? Row(
                  children: [
                    Expanded(child: _buildSchoolSelector()),
                    const SizedBox(width: 16),
                    Expanded(child: _buildClassSelector()),
                  ],
                )
              : Column(
                  children: [
                    _buildSchoolSelector(),
                    const SizedBox(height: 12),
                    _buildClassSelector(),
                  ],
                ),
          const SizedBox(height: 16),
          
          // Academic Year
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _startYearController,
                  decoration: InputDecoration(
                    labelText: 'Start Year',
                    prefixIcon: const Icon(Icons.calendar_today),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: isTablet ? 16 : 12,
                      vertical: isTablet ? 16 : 12,
                    ),
                  ),
                  onChanged: (_) => _onFilterChanged(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text('-', style: TextStyle(fontSize: isTablet ? 20 : 18, fontWeight: FontWeight.bold)),
              ),
              Expanded(
                child: TextFormField(
                  controller: _endYearController,
                  decoration: InputDecoration(
                    labelText: 'End Year',
                    prefixIcon: const Icon(Icons.event),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: isTablet ? 16 : 12,
                      vertical: isTablet ? 16 : 12,
                    ),
                  ),
                  onChanged: (_) => _onFilterChanged(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Date Selection
          isHistoryMode ? _buildDateRangeSelector() : _buildSingleDateSelector(),
        ],
      ),
    );
  }

  Widget _buildSchoolSelector() {
    return Obx(() {
      final schools = schoolController.schools;
      final selectedId = schoolController.selectedSchool.value?.id;

      return DropdownButtonFormField<School>(
        decoration: InputDecoration(
          hintText: 'Choose School',
          hintStyle: TextStyle(color: Colors.grey.shade600),
          prefixIcon: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.primaryBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 20),
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        dropdownColor: Colors.white,
        menuMaxHeight: 300,
        borderRadius: BorderRadius.circular(12),
        icon: Container(
          margin: const EdgeInsets.only(right: 12),
          child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
        ),
        style: TextStyle(
          color: Colors.grey.shade800,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
        value: selectedId == null ? null : schools.firstWhereOrNull((s) => s.id == selectedId),
        selectedItemBuilder: (context) {
          return schools.map((s) {
            return Text(
              s.name,
              style: TextStyle(
                color: Colors.grey.shade800,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            );
          }).toList();
        },
        items: schools.map((s) {
          return DropdownMenuItem<School>(
            value: s,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 16),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      s.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
        onChanged: _onSchoolChanged,
      );
    });
  }

  Widget _buildClassSelector() {
    return Obx(() {
      final classes = schoolController.classes;
      final selectedId = selectedClass?.id;

      return DropdownButtonFormField<SchoolClass>(
        decoration: InputDecoration(
          hintText: 'Choose Class',
          hintStyle: TextStyle(color: Colors.grey.shade600),
          prefixIcon: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.primaryBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(Icons.class_, color: AppTheme.primaryBlue, size: 20),
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        dropdownColor: Colors.white,
        menuMaxHeight: 300,
        borderRadius: BorderRadius.circular(12),
        icon: Container(
          margin: const EdgeInsets.only(right: 12),
          child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
        ),
        style: TextStyle(
          color: Colors.grey.shade800,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
        value: selectedId == null ? null : classes.firstWhereOrNull((c) => c.id == selectedId),
        selectedItemBuilder: (context) {
          return classes.map((c) {
            return Text(
              c.name,
              style: TextStyle(
                color: Colors.grey.shade800,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            );
          }).toList();
        },
        items: classes.map((c) {
          return DropdownMenuItem<SchoolClass>(
            value: c,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Icon(Icons.class_, color: AppTheme.primaryBlue, size: 16),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      c.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
        onChanged: (c) {
          if (mounted) {
            setState(() => selectedClass = c);
            _onFilterChanged();
          }
        },
      );
    });
  }

  Widget _buildSingleDateSelector() {
    return InkWell(
      onTap: () async {
        final d = await showDatePicker(
          context: context,
          initialDate: selectedDate,
          firstDate: DateTime(2020),
          lastDate: DateTime(2030),
        );
        if (d != null && mounted) {
          setState(() => selectedDate = d);
          _onFilterChanged();
        }
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(8),
          color: Colors.grey.shade50,
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_today, color: Colors.purple.shade600),
            const SizedBox(width: 12),
            Text(
              'Date: ${selectedDate.toString().split(' ')[0]}',
              style: const TextStyle(fontSize: 16),
            ),
            const Spacer(),
            const Icon(Icons.arrow_drop_down),
          ],
        ),
      ),
    );
  }

  Widget _buildDateRangeSelector() {
    return Row(
      children: [
        Expanded(
          child: InkWell(
            onTap: () async {
              final d = await showDatePicker(
                context: context,
                initialDate: startDate,
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (d != null && mounted) {
                setState(() => startDate = d);
                _onFilterChanged();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(8),
                color: Colors.grey.shade50,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('From', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                  Text(startDate.toString().split(' ')[0]),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: InkWell(
            onTap: () async {
              final d = await showDatePicker(
                context: context,
                initialDate: endDate,
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (d != null && mounted) {
                setState(() => endDate = d);
                _onFilterChanged();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(8),
                color: Colors.grey.shade50,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('To', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                  Text(endDate.toString().split(' ')[0]),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCollapsibleSummary(bool isLandscape, bool isTablet) {
    final screenSize = MediaQuery.of(context).size;
    final total = attendanceRecords.length;
    final present = attendanceRecords.where((r) => r['status'] == 'present').length;
    final absent = total - present;
    final isExpanded = total > 0;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: isExpanded ? null : 50,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(isTablet ? 16 : 12),
        child: isExpanded
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Icon(Icons.analytics, color: Colors.purple.shade600, size: isTablet ? 20 : 18),
                      SizedBox(width: isTablet ? 8 : 6),
                      Text('Summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: isTablet ? 16 : 14)),
                      const Spacer(),
                      Text('$present/$total Present', style: TextStyle(fontSize: isTablet ? 14 : 12, color: Colors.green)),
                    ],
                  ),
                  SizedBox(height: isTablet ? 12 : 8),
                  isLandscape && isTablet
                      ? Row(
                          children: [
                            Expanded(child: _buildSummaryCard('Total', total.toString(), Colors.blue, isTablet)),
                            SizedBox(width: isTablet ? 8 : 6),
                            Expanded(child: _buildSummaryCard('Present', present.toString(), Colors.green, isTablet)),
                            SizedBox(width: isTablet ? 8 : 6),
                            Expanded(child: _buildSummaryCard('Absent', absent.toString(), Colors.red, isTablet)),
                          ],
                        )
                      : Wrap(
                          spacing: isTablet ? 8 : 6,
                          runSpacing: isTablet ? 8 : 6,
                          children: [
                            SizedBox(
                              width: (screenSize.width - (isTablet ? 80 : 60)) / 3,
                              child: _buildSummaryCard('Total', total.toString(), Colors.blue, isTablet),
                            ),
                            SizedBox(
                              width: (screenSize.width - (isTablet ? 80 : 60)) / 3,
                              child: _buildSummaryCard('Present', present.toString(), Colors.green, isTablet),
                            ),
                            SizedBox(
                              width: (screenSize.width - (isTablet ? 80 : 60)) / 3,
                              child: _buildSummaryCard('Absent', absent.toString(), Colors.red, isTablet),
                            ),
                          ],
                        ),
                  SizedBox(height: isTablet ? 12 : 8),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => _bulkUpdateStatus('present'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green.shade100,
                            foregroundColor: Colors.green.shade700,
                            padding: EdgeInsets.symmetric(vertical: isTablet ? 12 : 8),
                          ),
                          child: Text('All Present', style: TextStyle(fontSize: isTablet ? 14 : 12)),
                        ),
                      ),
                      SizedBox(width: isTablet ? 8 : 6),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => _bulkUpdateStatus('absent'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red.shade100,
                            foregroundColor: Colors.red.shade700,
                            padding: EdgeInsets.symmetric(vertical: isTablet ? 12 : 8),
                          ),
                          child: Text('All Absent', style: TextStyle(fontSize: isTablet ? 14 : 12)),
                        ),
                      ),
                    ],
                  ),
                ],
              )
            : Row(
                children: [
                  Icon(Icons.analytics, color: Colors.purple.shade600, size: 18),
                  const SizedBox(width: 8),
                  Text('Summary: $present/$total Present', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                ],
              ),
      ),
    );
  }

  Widget _buildSummaryCard(String title, String value, Color color, bool isTablet) {
    return Container(
      padding: EdgeInsets.all(isTablet ? 12 : 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(isTablet ? 8 : 6),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: isTablet ? 20 : 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: isTablet ? 12 : 10,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContentArea(bool isTablet) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: isHistoryMode ? _buildHistoryList() : _buildDailyList(),
    );
  }

  Widget _buildDailyList() {
    if (attendanceRecords.isEmpty) {
      return const Center(
        child: Text(
          'No students found',
          style: TextStyle(fontSize: 14, color: Colors.grey),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: attendanceRecords.length,
      itemBuilder: (_, i) {
        final r = attendanceRecords[i];
        final isPresent = _normalizeStatus(r['status']) == 'present';
        
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: isPresent ? Colors.green.shade50 : Colors.red.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isPresent ? Colors.green.shade200 : Colors.red.shade200,
            ),
          ),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: isPresent ? Colors.green : Colors.red,
              child: Text(
                r['rollNumber']?.toString() ?? '?',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(
              r['studentName'] ?? 'Unknown Student',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            trailing: DropdownButton<String>(
              value: _normalizeStatus(r['status']),
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(value: 'present', child: Text('Present')),
                DropdownMenuItem(value: 'absent', child: Text('Absent')),
              ],
              onChanged: (v) {
                if (mounted) {
                  setState(() {
                    attendanceRecords[i]['status'] = v!;
                  });
                }
              },
            ),
          ),
        );
      },
    );
  }

  Widget _buildHistoryList() {
    if (historyRecords.isEmpty) {
      return const Center(
        child: Text(
          'No history found',
          style: TextStyle(fontSize: 14, color: Colors.grey),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: historyRecords.length,
      itemBuilder: (_, i) {
        final item = historyRecords[i];
        final records = item['records'] ?? [];
        final present = records.where((r) => r['status'] == 'present').length;
        final absent = records.where((r) => r['status'] == 'absent').length;

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: ExpansionTile(
            title: Text(
              item['date']?.toString().split('T')[0] ?? '',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle: Text('By: ${item['takenBy']?['userName'] ?? 'Unknown'}'),
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _statusChip('Present', present, Colors.green),
                        _statusChip('Absent', absent, Colors.red),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ...records.map<Widget>((s) => ListTile(
                      leading: CircleAvatar(
                        backgroundColor: s['status'] == 'present' ? Colors.green : Colors.red,
                        child: Text(
                          s['rollNumber']?.toString() ?? '',
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ),
                      title: Text(s['studentName'] ?? ''),
                      dense: true,
                    )),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSaveButton() {
    return Container(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: _saveAttendance,
        icon: const Icon(Icons.save),
        label: const Text('Save Attendance'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.purple.shade600,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  Widget _statusChip(String label, int count, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        '$label: $count',
        style: TextStyle(color: color, fontWeight: FontWeight.bold),
      ),
    );
  }

  // Helper methods
  String _normalizeStatus(String? status) {
    final v = status?.toLowerCase();
    return (v == 'present' || v == 'absent') ? v! : 'present';
  }

  void _onSchoolChanged(School? school) {
    schoolController.selectedSchool.value = school;

    if (mounted) {
      setState(() {
        selectedClass = null;
        attendanceRecords.clear();
        historyRecords.clear();
      });
    }

    if (school != null) {
      schoolController.getAllClasses(school.id).then((_) {
        if (schoolController.classes.isNotEmpty && mounted) {
          setState(() {
            selectedClass = schoolController.classes.first;
          });
          _onFilterChanged();
        }
      });
    }
  }

  void _onFilterChanged() {
    if (schoolController.selectedSchool.value == null || selectedClass == null) return;

    if (isHistoryMode) {
      _loadAttendanceHistory();
    } else {
      _loadAttendanceSheet();
    }
  }

  Future<void> _loadAttendanceSheet() async {
    final sheet = await attendanceController.getAttendanceSheet(
      schoolId: schoolController.selectedSchool.value!.id,
      classId: selectedClass!.id,
      date: selectedDate.toString().split(' ')[0],
      academicYear: academicYear,
    );

    if (sheet != null && mounted) {
      setState(() {
        attendanceRecords = List<Map<String, dynamic>>.from(sheet).map((r) {
          r['status'] = _normalizeStatus(r['status']);
          return r;
        }).toList();
      });
    } else {
      // If no sheet found, try to get students for the class
      final students = await attendanceController.getStudentsForAttendance(
        schoolId: schoolController.selectedSchool.value!.id,
        classId: selectedClass!.id,
      );
      
      if (students != null && mounted) {
        setState(() {
          attendanceRecords = List<Map<String, dynamic>>.from(students).map((student) {
            return {
              'studentId': student['_id'] ?? student['id'],
              'studentName': student['name'] ?? 'Unknown',
              'rollNumber': student['rollNumber'] ?? '',
              'status': 'present', // Default status
            };
          }).toList();
        });
      }
    }
  }

  Future<void> _loadAttendanceHistory() async {
    final response = await attendanceController.getAttendanceHistory(
      schoolId: schoolController.selectedSchool.value!.id,
      classId: selectedClass!.id,
      academicYear: academicYear,
      startDate: startDate.toString().split(' ')[0],
      endDate: endDate.toString().split(' ')[0],
    );

    if (response != null && response is List && mounted) {
      setState(() {
        historyRecords = List<Map<String, dynamic>>.from(response);
      });
    }
  }

  void _saveAttendance() {
    attendanceController.markAttendance(
      schoolId: schoolController.selectedSchool.value!.id,
      classId: selectedClass!.id,
      date: selectedDate.toString().split(' ')[0],
      academicYear: academicYear,
      records: attendanceRecords,
    );
  }

  void _bulkUpdateStatus(String status) {
    if (mounted) {
      setState(() {
        for (final r in attendanceRecords) {
          r['status'] = status;
        }
      });
    }
  }
}

class _FeeStructureTab extends StatefulWidget {
  @override
  State<_FeeStructureTab> createState() => _FeeStructureTabState();
}

class _FeeStructureTabState extends State<_FeeStructureTab> {
  final feeController = Get.put(FeeStructureController());
  final schoolController = Get.find<SchoolController>();

  final admissionFeeController = TextEditingController();
  final firstTermController = TextEditingController();
  final secondTermController = TextEditingController();
  final busFirstTermController = TextEditingController();
  final busSecondTermController = TextEditingController();

  final selectedClass = ValueNotifier<SchoolClass?>(null);
  final selectedStudentType = ValueNotifier<String>('old'); // 'old' or 'new'
  final isStudentTypeExpanded = ValueNotifier<bool>(true); // Track if student type selector is expanded

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;
    
    return SafeArea(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.blue.shade50, Colors.indigo.shade50],
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(isTablet ? 24 : 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Section
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppTheme.primaryBlue, Colors.indigo.shade600],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primaryBlue.withOpacity(0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.payment,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Fee Structure Management',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: isTablet ? 24 : 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Configure fees for different classes',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.8),
                                fontSize: isTablet ? 16 : 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Selection Cards - Collapsible
                _buildCollapsibleSelectors(),

                const SizedBox(height: 16),

                // Student Type Selector
                _buildStudentTypeSelector(),

                const SizedBox(height: 20),

                // Fee Structure Form
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Form Header
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.receipt_long,
                              color: AppTheme.primaryBlue,
                              size: 24,
                            ),
                            const SizedBox(width: 12),
                            Text(
                              'Fee Details',
                              style: TextStyle(
                                fontSize: isTablet ? 20 : 18,
                                fontWeight: FontWeight.bold,
                                color: AppTheme.primaryBlue,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Form Content - Now part of the overall scroll
                      Padding(
                        padding: EdgeInsets.all(isTablet ? 24 : 20),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            isLandscape && isTablet
                                ? _buildLandscapeForm()
                                : _buildPortraitForm(),
                            const SizedBox(height: 20),
                            // Save Button
                            _buildSaveButton(),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStudentTypeSelector() {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;

    return ValueListenableBuilder<bool>(
      valueListenable: isStudentTypeExpanded,
      builder: (context, isExpanded, child) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: isExpanded ? null : 60,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: isExpanded
                ? _buildExpandedStudentTypeSelector(isTablet)
                : _buildCompactStudentTypeSelector(isTablet),
          ),
        );
      },
    );
  }

  Widget _buildCompactStudentTypeSelector(bool isTablet) {
    return ValueListenableBuilder<String>(
      valueListenable: selectedStudentType,
      builder: (context, studentType, child) {
        return InkWell(
          onTap: () => isStudentTypeExpanded.value = true,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: EdgeInsets.all(isTablet ? 20 : 16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    studentType == 'old' ? Icons.school : Icons.person_add,
                    color: AppTheme.primaryBlue,
                    size: 18
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Student Type: ${studentType == 'old' ? 'Old Students' : 'New Students'}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  onPressed: () => isStudentTypeExpanded.value = true,
                  icon: const Icon(Icons.edit, size: 18),
                  tooltip: 'Change Student Type',
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildExpandedStudentTypeSelector(bool isTablet) {
    return ValueListenableBuilder<String>(
      valueListenable: selectedStudentType,
      builder: (context, studentType, child) {
        return Padding(
          padding: EdgeInsets.all(isTablet ? 20 : 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      studentType == 'old' ? Icons.school : Icons.person_add,
                      color: AppTheme.primaryBlue,
                      size: 20
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Student Type',
                    style: TextStyle(
                      fontSize: isTablet ? 18 : 16,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryBlue,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () => isStudentTypeExpanded.value = false,
                    icon: const Icon(Icons.expand_less, size: 20),
                    tooltip: 'Collapse',
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.3)),
                  gradient: LinearGradient(
                    colors: [Colors.white, Colors.blue.shade50],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    hintText: 'Select student type',
                    hintStyle: TextStyle(color: Colors.grey.shade600),
                    prefixIcon: Container(
                      margin: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryBlue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(Icons.category, color: AppTheme.primaryBlue, size: 20),
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  ),
                  dropdownColor: Colors.white,
                  menuMaxHeight: 200,
                  borderRadius: BorderRadius.circular(12),
                  icon: Container(
                    margin: const EdgeInsets.only(right: 12),
                    child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
                  ),
                  style: TextStyle(
                    color: Colors.grey.shade800,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                  value: selectedStudentType.value,
                  items: const [
                    DropdownMenuItem<String>(
                      value: 'old',
                      child: Row(
                        children: [
                          Icon(Icons.school, color: Colors.blue, size: 20),
                          SizedBox(width: 12),
                          Text('Old Students', style: TextStyle(fontWeight: FontWeight.w500)),
                        ],
                      ),
                    ),
                    DropdownMenuItem<String>(
                      value: 'new',
                      child: Row(
                        children: [
                          Icon(Icons.person_add, color: Colors.green, size: 20),
                          SizedBox(width: 12),
                          Text('New Students', style: TextStyle(fontWeight: FontWeight.w500)),
                        ],
                      ),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      selectedStudentType.value = value;
                      // Reload fee structure when student type changes
                      if (schoolController.selectedSchool.value != null && selectedClass.value != null) {
                        _loadFeeStructure(schoolController.selectedSchool.value!.id, selectedClass.value!.id);
                      }
                    }
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCollapsibleSelectors() {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;

    return Obx(() {
      final hasSelections = schoolController.selectedSchool.value != null && selectedClass.value != null;

      return AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: hasSelections ? 60 : null,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: hasSelections
              ? _buildCompactSelectors()
              : _buildFullSelectors(isLandscape, isTablet),
        ),
      );
    });
  }

  Widget _buildCompactSelectors() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(Icons.school, color: AppTheme.primaryBlue, size: 20),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              schoolController.selectedSchool.value?.name ?? '',
              style: const TextStyle(fontWeight: FontWeight.w600),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 16),
          Icon(Icons.class_, color: AppTheme.primaryBlue, size: 20),
          const SizedBox(width: 8),
          Text(
            selectedClass.value?.name ?? '',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const Spacer(),
          IconButton(
            onPressed: () {
              setState(() {
                schoolController.selectedSchool.value = null;
                selectedClass.value = null;
                _clearForm();
              });
            },
            icon: const Icon(Icons.edit, size: 20),
            tooltip: 'Change Selection',
          ),
        ],
      ),
    );
  }

  Widget _buildFullSelectors(bool isLandscape, bool isTablet) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: isLandscape && isTablet
          ? Row(
              children: [
                Expanded(child: _buildSchoolDropdown()),
                const SizedBox(width: 16),
                Expanded(child: _buildClassDropdown()),
              ],
            )
          : Column(
              children: [
                _buildSchoolDropdown(),
                const SizedBox(height: 16),
                _buildClassDropdown(),
              ],
            ),
    );
  }

  Widget _buildSchoolDropdown() {
    return Obx(() => DropdownButtonFormField<School>(
      decoration: InputDecoration(
        hintText: 'Choose School',
        hintStyle: TextStyle(color: Colors.grey.shade600),
        prefixIcon: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppTheme.primaryBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 20),
        ),
        border: InputBorder.none,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      ),
      dropdownColor: Colors.white,
      menuMaxHeight: 300,
      borderRadius: BorderRadius.circular(12),
      icon: Container(
        margin: const EdgeInsets.only(right: 12),
        child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
      ),
      style: TextStyle(
        color: Colors.grey.shade800,
        fontSize: 16,
        fontWeight: FontWeight.w500,
      ),
      value: schoolController.selectedSchool.value,
      selectedItemBuilder: (context) {
        return schoolController.schools.map((school) {
          return Text(
            school.name,
            style: TextStyle(
              color: Colors.grey.shade800,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            overflow: TextOverflow.ellipsis,
          );
        }).toList();
      },
      items: schoolController.schools.map((school) {
        return DropdownMenuItem<School>(
          value: school,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 16),
                ),
                const SizedBox(width: 12),
                Text(
                  school.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        );
      }).toList(),
      onChanged: (school) {
        setState(() {
          schoolController.selectedSchool.value = school;
          selectedClass.value = null;
          _clearForm();
        });
        if (school != null) {
          schoolController.getAllClasses(school.id);
        }
      },
    ));
  }

  Widget _buildClassDropdown() {
    return ValueListenableBuilder<SchoolClass?>(
      valueListenable: selectedClass,
      builder: (context, value, child) {
        return DropdownButtonFormField<SchoolClass>(
          decoration: InputDecoration(
            hintText: 'Choose Class',
            hintStyle: TextStyle(color: Colors.grey.shade600),
            prefixIcon: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppTheme.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.class_, color: AppTheme.primaryBlue, size: 20),
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          ),
          dropdownColor: Colors.white,
          menuMaxHeight: 300,
          borderRadius: BorderRadius.circular(12),
          icon: Container(
            margin: const EdgeInsets.only(right: 12),
            child: Icon(Icons.keyboard_arrow_down, color: AppTheme.primaryBlue),
          ),
          style: TextStyle(
            color: Colors.grey.shade800,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
          value: schoolController.classes.contains(value) ? value : null,
          selectedItemBuilder: (context) {
            return schoolController.classes.map((cls) {
              return Text(
                cls.name,
                style: TextStyle(
                  color: Colors.grey.shade800,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
                overflow: TextOverflow.ellipsis,
              );
            }).toList();
          },
          items: schoolController.classes.map((cls) {
            return DropdownMenuItem<SchoolClass>(
              value: cls,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryBlue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Icon(Icons.class_, color: AppTheme.primaryBlue, size: 16),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      cls.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
          onChanged: (cls) {
            setState(() {
              selectedClass.value = cls;
            });
            if (cls != null && schoolController.selectedSchool.value != null) {
              _loadFeeStructure(schoolController.selectedSchool.value!.id, cls.id);
            }
          },
        );
      },
    );
  }

  Widget _buildPortraitForm() {
    return Column(
      children: [
        _buildFeeCard('Admission Fee', admissionFeeController, Icons.login, Colors.green),
        const SizedBox(height: 16),
        _buildFeeCard('First Term Amount', firstTermController, Icons.looks_one, Colors.blue),
        const SizedBox(height: 16),
        _buildFeeCard('Second Term Amount', secondTermController, Icons.looks_two, Colors.orange),
        const SizedBox(height: 16),
        _buildFeeCard('Bus First Term', busFirstTermController, Icons.directions_bus, Colors.teal),
        const SizedBox(height: 16),
        _buildFeeCard('Bus Second Term', busSecondTermController, Icons.directions_bus_filled, Colors.indigo),
      ],
    );
  }

  Widget _buildLandscapeForm() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _buildFeeCard('Admission Fee', admissionFeeController, Icons.login, Colors.green)),
            const SizedBox(width: 16),
            Expanded(child: _buildFeeCard('First Term Amount', firstTermController, Icons.looks_one, Colors.blue)),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: _buildFeeCard('Second Term Amount', secondTermController, Icons.looks_two, Colors.orange)),
            const SizedBox(width: 16),
            Expanded(child: _buildFeeCard('Bus First Term', busFirstTermController, Icons.directions_bus, Colors.teal)),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: Container()), // Empty space for balance
            const SizedBox(width: 16),
            Expanded(child: _buildFeeCard('Bus Second Term', busSecondTermController, Icons.directions_bus_filled, Colors.indigo)),
          ],
        ),
      ],
    );
  }

  Widget _buildFeeCard(String label, TextEditingController controller, IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: color,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: controller,
              decoration: InputDecoration(
                prefixText: '₹ ',
                hintText: 'Enter amount',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: color.withOpacity(0.3)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: color, width: 2),
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
              keyboardType: TextInputType.number,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSaveButton() {
    // Check if user has permission to save fee structure
    final authController = Get.find<AuthController>();
    final currentUserRole = authController.user.value?.role?.toLowerCase() ?? '';
    final canSave = ApiPermissions.hasApiAccess(currentUserRole, 'POST /api/feestructure/set');
    
    // Don't show save button if user doesn't have permission
    if (!canSave) {
      return const SizedBox.shrink();
    }
    
    return SizedBox(
      width: double.infinity,
      child: Obx(() => ElevatedButton(
        onPressed: feeController.isLoading.value ? null : _saveFeeStructure,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.primaryBlue,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 4,
        ),
        child: feeController.isLoading.value
            ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              )
            : const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.save, size: 20),
                  SizedBox(width: 8),
                  Text(
                    'Save Fee Structure',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
      )),
    );
  }

  void _clearForm() {
    admissionFeeController.clear();
    firstTermController.clear();
    secondTermController.clear();
    busFirstTermController.clear();
    busSecondTermController.clear();
  }

  void _loadFeeStructure(String schoolId, String classId) async {
    final studentType = selectedStudentType.value;
    final feeStructure = await feeController.getFeeStructureByClass(schoolId, classId, type: studentType);
    if (feeStructure != null) {
      // Handle both direct feeHead and nested data.feeHead formats
      final feeHead = feeStructure['feeHead'] ?? feeStructure['data']?['feeHead'] ?? {};
      admissionFeeController.text = feeHead['admissionFee']?.toString() ?? '';
      firstTermController.text = feeHead['firstTermAmt']?.toString() ?? '';
      secondTermController.text = feeHead['secondTermAmt']?.toString() ?? '';
      busFirstTermController.text = feeHead['busFirstTermAmt']?.toString() ?? '';
      busSecondTermController.text = feeHead['busSecondTermAmt']?.toString() ?? '';
    } else {
      // Clear form if no fee structure found for this student type
      _clearForm();
    }
  }

  void _saveFeeStructure() {
    if (schoolController.selectedSchool.value == null) {
      Get.snackbar(
        'Error',
        'Please select a school first',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
      return;
    }

    final selectedClass = this.selectedClass.value;
    if (selectedClass == null) {
      Get.snackbar(
        'Error',
        'Please select a class',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
      return;
    }

    feeController.setFeeStructure(
      schoolId: schoolController.selectedSchool.value!.id,
      classId: selectedClass.id,
      type: selectedStudentType.value,
      feeHead: {
        'admissionFee': double.tryParse(admissionFeeController.text) ?? 0,
        'firstTermAmt': double.tryParse(firstTermController.text) ?? 0,
        'secondTermAmt': double.tryParse(secondTermController.text) ?? 0,
        'busFirstTermAmt': double.tryParse(busFirstTermController.text) ?? 0,
        'busSecondTermAmt': double.tryParse(busSecondTermController.text) ?? 0,
      },
    );
  }
}
  void _showSectionDetailsDialog(BuildContext context, Section section) {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;
    
    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          width: isTablet ? (isLandscape ? 600 : 500) : screenSize.width * 0.9,
          constraints: BoxConstraints(
            maxHeight: screenSize.height * 0.8,
            maxWidth: isTablet ? 600 : screenSize.width * 0.95,
          ),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white, AppTheme.primaryBlue.withOpacity(0.02)],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Container(
                padding: EdgeInsets.all(isTablet ? 24 : 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryBlue, Colors.indigo.shade600],
                  ),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.group, color: Colors.white, size: 28),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Section ${section.name}',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: isTablet ? 24 : 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Class ${section.className ?? "N/A"}',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: isTablet ? 16 : 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Get.back(),
                      icon: const Icon(Icons.close, color: Colors.white, size: 24),
                    ),
                  ],
                ),
              ),
              
              // Content
              Flexible(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(isTablet ? 24 : 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Basic Info Cards
                      isLandscape && isTablet
                          ? Row(
                              children: [
                                Expanded(child: _buildInfoCard('Section Name', section.name, Icons.label, Colors.blue)),
                                const SizedBox(width: 16),
                                Expanded(child: _buildInfoCard('Class', section.className ?? 'N/A', Icons.class_, Colors.green)),
                              ],
                            )
                          : Column(
                              children: [
                                _buildInfoCard('Section Name', section.name, Icons.label, Colors.blue),
                                const SizedBox(height: 12),
                                _buildInfoCard('Class', section.className ?? 'N/A', Icons.class_, Colors.green),
                              ],
                            ),
                      const SizedBox(height: 16),
                      
                      // Room & Capacity
                      isLandscape && isTablet
                          ? Row(
                              children: [
                                Expanded(child: _buildInfoCard('Room Number', section.roomNumber ?? 'Not Assigned', Icons.room, Colors.orange)),
                                const SizedBox(width: 16),
                                Expanded(child: _buildInfoCard('Capacity', section.capacity?.toString() ?? 'Not Set', Icons.people, Colors.purple)),
                              ],
                            )
                          : Column(
                              children: [
                                _buildInfoCard('Room Number', section.roomNumber ?? 'Not Assigned', Icons.room, Colors.orange),
                                const SizedBox(height: 12),
                                _buildInfoCard('Capacity', section.capacity?.toString() ?? 'Not Set', Icons.people, Colors.purple),
                              ],
                            ),
                      const SizedBox(height: 20),
                      
                      // Teachers Section
                      if (section.classTeachers != null && section.classTeachers!.isNotEmpty) ...[
                        Text(
                          'Class Teachers',
                          style: TextStyle(
                            fontSize: isTablet ? 20 : 18,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryBlue,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ...section.classTeachers!.map((teacher) => Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.teal.shade50, Colors.teal.shade100],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.teal.shade200),
                          ),
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: Colors.teal,
                                radius: 20,
                                child: Text(
                                  (teacher['userName'] ?? 'U')[0].toUpperCase(),
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      teacher['userName'] ?? 'Unknown',
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                    ),
                                    if (teacher['email'] != null)
                                      Text(
                                        teacher['email'],
                                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                                      ),
                                    if (teacher['phoneNo'] != null)
                                      Text(
                                        teacher['phoneNo'],
                                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                                      ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.teal,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Text(
                                  'Teacher',
                                  style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                                ),
                              ),
                            ],
                          ),
                        )),
                      ] else ...[
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.info_outline, color: Colors.grey[600]),
                              const SizedBox(width: 12),
                              Text(
                                'No teachers assigned ',
                                style: TextStyle(color: Colors.grey[600], fontSize: 16),
                              ),
                            ],
                          ),
                        ),
                      ],
                      
                      const SizedBox(height: 20),
                      
                      // Metadata

                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildInfoCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.1), color.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }