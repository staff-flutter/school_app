import 'package:flutter/material.dart';

class AppTheme {
  // 🎨 Global Background Colors
  static const Color appBackground = Color(0xFFF4F7FE);
  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color dividerColor = Color(0xFFE5E7EB);
  static const Color mutedText = Color(0xFF6B7280);
  static const Color primaryText = Color(0xFF111827);
  static const Color TealColor = Color(0xFF80CBC4);
  // 📚 Subject Card Gradient System
  // Geography (Blue/Purple)
  static const LinearGradient TealGradient = LinearGradient(
    colors: [AppTheme.TealColor, Color(0xFF8FA7FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient geographyGradient = LinearGradient(
    colors: [Color(0xFF5B7CFA), Color(0xFF8FA7FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient geographySoftGradient = LinearGradient(
    colors: [Color(0xFFDDD6FE), Color(0xFFEDE9FE)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // Math (Orange/Coral)
  static const LinearGradient mathGradient = LinearGradient(
    colors: [Color(0xFFFF8A4C), Color(0xFFFFC078)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient mathSoftGradient = LinearGradient(
    colors: [Color(0xFFFED7AA), Color(0xFFFEF3C7)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // Biology (Green)
  static const LinearGradient biologyGradient = LinearGradient(
    colors: [Color(0xFF2FBF71), Color(0xFF6EE7B7)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient biologySoftGradient = LinearGradient(
    colors: [Color(0xFFD1FAE5), Color(0xFFECFDF5)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // Physics (Purple/Blue)
  static const LinearGradient physicsGradient = LinearGradient(
    colors: [Color(0xFF8B5CF6), Color(0xFFA78BFA)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient physicsSoftGradient = LinearGradient(
    colors: [Color(0xFFEDE9FE), Color(0xFFF3E8FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // English (Pink/Rose)
  static const LinearGradient englishGradient = LinearGradient(
    colors: [Color(0xFFEC4899), Color(0xFFF472B6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient englishSoftGradient = LinearGradient(
    colors: [Color(0xFFFCE7F3), Color(0xFFFDF2F8)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // Chemistry (Yellow/Gold)
  static const LinearGradient chemistryGradient = LinearGradient(
    colors: [Color(0xFFFBBF24), Color(0xFFFDE68A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient chemistrySoftGradient = LinearGradient(
    colors: [Color(0xFFFEF3C7), Color(0xFFFFFBEB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // 🎯 Primary System Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF4F6EF7), Color(0xFF6C8CFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient successGradient = LinearGradient(
    colors: [Color(0xFF2FBF71), Color(0xFF6EE7B7)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient warningGradient = LinearGradient(
    colors: [Color(0xFFFBBF24), Color(0xFFFDE68A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient errorGradient = LinearGradient(
    colors: [Color(0xFFEF4444), Color(0xFFFCA5A5)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // 📊 Chart & Statistics Colors
  static const Color lowScore = Color(0xFFEF4444);
  static const Color mediumScore = Color(0xFFFBBF24);
  static const Color highScore = Color(0xFF22C55E);
  static const Color gridLine = Color(0xFFE5E7EB);
  
  // 🎨 Text Colors on Different Backgrounds
  static const Color titleOnGradient = Color(0xFFFFFFFF);
  static const Color subtitleOnGradient = Color(0xFFE0E7FF);
  static const Color titleOnWhite = Color(0xFF111827);
  static const Color subtitleOnWhite = Color(0xFF6B7280);
  
  // Legacy colors for backward compatibility
  static const Color primaryBlue = Color(0xFF4F6EF7);
  static const Color successGreen = Color(0xFF22C55E);
  static const Color warningYellow = Color(0xFFFBBF24);
  static const Color errorRed = Color(0xFFEF4444);
  static const Color mathOrange = Color(0xFFFF8A4C);
  static const Color geographyBlue = Color(0xFF5B7CFA);
  static const Color biologyGreen = Color(0xFF2FBF71);
  static const Color chemistryYellow = Color(0xFFFBBF24);
  
  // Legacy gradients
  static const LinearGradient cardGradient = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFF8FAFC)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const Color primaryBackground = appBackground;

  static const double radius = 16;
  static const double cardElevation = 4;

  static final ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: const ColorScheme.light(
      primary: primaryBlue,
      secondary: successGreen,
      background: appBackground,
      surface: cardBackground,
      error: errorRed,
      onPrimary: titleOnGradient,
      onBackground: primaryText,
      onSurface: primaryText,
    ),
    scaffoldBackgroundColor: appBackground,
    appBarTheme: const AppBarTheme(
      backgroundColor: primaryBlue,
      elevation: 0,
      centerTitle: true,
      iconTheme: IconThemeData(color: titleOnGradient),
      titleTextStyle: TextStyle(
        color: titleOnGradient,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
    ),
    tabBarTheme: const TabBarThemeData(
      labelColor: Colors.white,
      unselectedLabelColor: Colors.white70,
      indicatorColor: Colors.white,
      labelStyle: TextStyle(fontWeight: FontWeight.w600),
    ),
    cardTheme: CardThemeData(
      color: cardBackground,
      elevation: cardElevation,
      shadowColor: Colors.black.withOpacity(0.05),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radius),
      ),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        foregroundColor: titleOnGradient,
        minimumSize: const Size(double.infinity, 48),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radius),
        ),
        elevation: 2,
      ),
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: primaryBlue,
      foregroundColor: titleOnGradient,
    ),
    dividerColor: dividerColor,
    textTheme: const TextTheme(
      headlineLarge: TextStyle(color: titleOnWhite, fontWeight: FontWeight.bold),
      headlineMedium: TextStyle(color: titleOnWhite, fontWeight: FontWeight.w600),
      titleLarge: TextStyle(color: titleOnWhite, fontWeight: FontWeight.w600),
      titleMedium: TextStyle(color: titleOnWhite, fontWeight: FontWeight.w500),
      bodyLarge: TextStyle(color: titleOnWhite),
      bodyMedium: TextStyle(color: subtitleOnWhite),
      bodySmall: TextStyle(color: mutedText),
    ),
  );

  // 🎨 Helper Methods for Subject Colors
  static LinearGradient getSubjectGradient(String subject, {bool soft = false}) {
    switch (subject.toLowerCase()) {
      case 'geography':
        return soft ? geographySoftGradient : geographyGradient;
      case 'math':
      case 'mathematics':
        return soft ? mathSoftGradient : mathGradient;
      case 'biology':
        return soft ? biologySoftGradient : biologyGradient;
      case 'chemistry':
        return soft ? chemistrySoftGradient : chemistryGradient;
      default:
        return soft ? biologySoftGradient : primaryGradient;
    }
  }
  
  static Color getSubjectPrimaryColor(String subject) {
    switch (subject.toLowerCase()) {
      case 'geography': return geographyBlue;
      case 'math':
      case 'mathematics': return mathOrange;
      case 'biology': return biologyGreen;
      case 'chemistry': return chemistryYellow;
      default: return primaryBlue;
    }
  }
  
  static Color getScoreColor(double score) {
    if (score >= 80) return highScore;
    if (score >= 60) return mediumScore;
    return lowScore;
  }
  
  // Responsive breakpoints
  static bool isMobile(BuildContext context) => MediaQuery.of(context).size.width < 600;
  static bool isTablet(BuildContext context) => MediaQuery.of(context).size.width >= 600 && MediaQuery.of(context).size.width < 1200;
  static bool isDesktop(BuildContext context) => MediaQuery.of(context).size.width >= 1200;
  
  static double getResponsivePadding(BuildContext context) {
    if (isMobile(context)) return 16;
    if (isTablet(context)) return 24;
    return 32;
  }
  
  static int getGridColumns(BuildContext context) {
    if (isMobile(context)) return 1;
    if (isTablet(context)) return 2;
    return 3;
  }
}