import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/main_navigation_controller.dart';
import '../core/theme/app_theme.dart';

class MainWrapper extends StatelessWidget {
  final Widget child;
  
  const MainWrapper({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MainNavigationController>(
      init: MainNavigationController(),
      builder: (controller) {
        return Scaffold(
          body: SafeArea(child: child),
          bottomNavigationBar: Obx(() {
            final items = controller.navigationItems;
            if (items.isEmpty) return const SizedBox();
            
            return BottomNavigationBar(
              type: BottomNavigationBarType.fixed,
              currentIndex: controller.selectedIndex.value.clamp(0, items.length - 1),
              onTap: controller.onItemTapped,
              selectedItemColor: AppTheme.primaryBlue,
              unselectedItemColor: Colors.grey,
              backgroundColor: Colors.white,
              elevation: 8,
              items: items.map((item) => BottomNavigationBarItem(
                icon: Icon(_getIconData(item.label)),
                label: item.label,
              )).toList(),
            );
          }),
        );
      },
    );
  }

  IconData _getIconData(String label) {
    switch (label.toLowerCase()) {
      case 'dashboard':
        return Icons.dashboard;
      case 'users':
        return Icons.people;
      case 'students':
        return Icons.school;
      case 'fee collection':
        return Icons.payment;
      case 'teacher assignments':
        return Icons.assignment_ind;
      case 'fee structure':
        return Icons.account_balance_wallet;
      case 'attendance':
        return Icons.how_to_reg;
      case 'clubs':
        return Icons.groups;
      case 'announcements':
      case 'communications':
        return Icons.campaign;
      case 'records':
        return Icons.folder;
      case 'profile':
        return Icons.person;
      case 'expenses':
        return Icons.receipt_long;
      case 'reports':
        return Icons.analytics;
      case 'academics':
        return Icons.school;
      case 'schools':
        return Icons.business;
      case 'fees':
        return Icons.payment;
      case 'my classes':
        return Icons.class_;
      case 'subscription':
        return Icons.subscriptions;
      default:
        return Icons.home;
    }
  }
}