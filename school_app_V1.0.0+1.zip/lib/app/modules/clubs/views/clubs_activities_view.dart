import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:file_picker/file_picker.dart';
import 'package:school_app/app/core/widgets/gradient_card.dart';
import 'dart:io';
import '../../../controllers/school_controller.dart';
import '../../../controllers/subscription_controller.dart';
import '../../../controllers/club_controller.dart';
import '../../../views/subscription_management_view.dart';
import '../controllers/clubs_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/responsive_wrapper.dart';

import '../../../data/models/school_models.dart' hide Club;
import '../../../data/models/student_model.dart';
import '../../../data/models/club_model.dart';
import '../../auth/controllers/auth_controller.dart';
import '../../../controllers/my_children_controller.dart';
import 'club_detail_view.dart';
import 'video_detail_view.dart';

class ClubsActivitiesView extends GetView<ClubsController> {
  const ClubsActivitiesView({super.key});

  void _populateClassesFromChildren(SchoolController schoolController, MyChildrenController myChildrenController) {
    final classMap = <String, SchoolClass>{};
    
    for (var child in myChildrenController.children) {
      final classId = child['classId'];
      final className = child['className'];
      
      if (classId != null && classId.toString().isNotEmpty && className != null) {
        classMap[classId.toString()] = SchoolClass(
          id: classId.toString(),
          name: className.toString(),
          schoolId: schoolController.selectedSchool.value?.id ?? '',
          order: 0,
          hasSections: false,
        );
      }
    }
    
    if (classMap.isNotEmpty) {
      schoolController.classes.value = classMap.values.toList();
      
    }
  }

  @override
  Widget build(BuildContext context) {
    final schoolController = Get.find<SchoolController>();
    final subscriptionController = Get.isRegistered<SubscriptionController>()
        ? Get.find<SubscriptionController>()
        : null;

    // Always load schools for all users
    if (schoolController.schools.isEmpty && !schoolController.isLoading.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        schoolController.getAllSchools();
      });
    }

    // Load classes for selected school if not already loaded (only for non-parent users)
    final userRole = Get.find<AuthController>().user.value?.role?.toLowerCase() ?? '';
    final isParentUser = userRole == 'parent';

    // Load children data for parents and populate classes from children
    if (isParentUser && Get.isRegistered<MyChildrenController>()) {
      final myChildrenController = Get.find<MyChildrenController>();
      if (myChildrenController.children.isEmpty && !myChildrenController.isLoading.value) {
        WidgetsBinding.instance.addPostFrameCallback((_) async {
          await myChildrenController.loadMyChildren();
          _populateClassesFromChildren(schoolController, myChildrenController);
        });
      } else if (myChildrenController.children.isNotEmpty && schoolController.classes.isEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _populateClassesFromChildren(schoolController, myChildrenController);
        });
      }
    }

    if (!isParentUser && schoolController.selectedSchool.value != null &&
        schoolController.classes.isEmpty &&
        !schoolController.isLoading.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        schoolController.getAllClasses(schoolController.selectedSchool.value!.id);
      });
    }

    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: SafeArea(
        child: Obx(() {
          final selectedSchool = schoolController.selectedSchool.value;
          if (selectedSchool == null) {
            return SingleChildScrollView(
              child: Column(
                children: [
                  _buildModernHeader(context),
                  _buildSchoolSelector(context, schoolController),
                  _buildSelectSchoolPrompt(),
                ],
              ),
            );
          }

          // Only check subscription for correspondent and principal roles
          final userRole = Get.find<AuthController>().user.value?.role?.toLowerCase() ?? '';
          final requiresSubscriptionCheck = ['correspondent', 'principal'].contains(userRole);

          if (requiresSubscriptionCheck) {
            final hasAccess = subscriptionController?.hasModuleAccess('club') ?? false;
            if (!hasAccess) {
              return SingleChildScrollView(
                child: Column(
                  children: [
                    _buildModernHeader(context),
                    _buildSchoolSelector(context, schoolController),
                    _buildUpgradeRequiredWidget(context, 'Club'),
                  ],
                ),
              );
            }
          }

          return NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) {
              return [
                SliverToBoxAdapter(child: _buildModernHeader(context)),
                SliverToBoxAdapter(child: _buildSchoolSelector(context, schoolController)),
              ];
            },
            body: _buildTabContent(context),
          );
        }),
      ),
    );
  }

  Widget _buildModernHeader(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppTheme.primaryBlue, Colors.indigo.shade600],
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(isTablet ? 24 : 20),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.groups,
                color: Colors.white,
                size: 28,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Clubs & Activities',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: isTablet ? 24 : 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Manage school clubs and activities',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: isTablet ? 16 : 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSchoolSelector(BuildContext context, SchoolController schoolController) {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final authController = Get.find<AuthController>();
    final isCorrespondent = authController.user.value?.role == 'correspondent';
    
    return Container(
      margin: EdgeInsets.all(isTablet ? 20 : 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(isTablet ? 20 : 16),
        child: Obx(() {
          if (schoolController.isLoading.value && schoolController.schools.isEmpty) {
            return const Center(child: LinearProgressIndicator());
          }

          if (schoolController.schools.isEmpty) {
            return const Text("No schools available");
          }

          // For correspondent roles, show dropdown
          if (isCorrespondent) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        gradient: AppTheme.primaryGradient,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.school, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Select School',
                      style: TextStyle(
                        fontSize: isTablet ? 18 : 16,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.primaryText,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.3)),
                  ),
                  child: DropdownButtonFormField<School>(
                    value: schoolController.schools.contains(schoolController.selectedSchool.value)
                        ? schoolController.selectedSchool.value
                        : null,
                    hint: Text('Choose your school', style: TextStyle(color: Colors.grey.shade600)),
                    dropdownColor: Colors.white,
                    icon: Icon(Icons.arrow_drop_down, color: AppTheme.primaryBlue),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      prefixIcon: Icon(Icons.school, color: AppTheme.primaryBlue),
                    ),
                    items: schoolController.schools.map((school) {
                      return DropdownMenuItem<School>(
                        value: school,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryBlue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Icon(Icons.school, color: AppTheme.primaryBlue, size: 16),
                            ),
                            const SizedBox(width: 12),
                            Flexible(
                              child: Text(
                                school.name,
                                style: const TextStyle(fontWeight: FontWeight.w500),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (School? value) {
                      if (value != null) {
                        schoolController.selectedSchool.value = value;
                        schoolController.classes.clear();
                        schoolController.getAllClasses(value.id);
                        if (Get.isRegistered<SubscriptionController>()) {
                          Get.find<SubscriptionController>().loadSubscription(value.id);
                        }
                      }
                    },
                  ),
                ),
              ],
            );
          }
          
          // For non-correspondent roles, show readonly school name
          return Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.school, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'School',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      schoolController.selectedSchool.value?.name ?? 'Loading...',
                      style: TextStyle(
                        fontSize: isTablet ? 18 : 16,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.primaryText,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildSelectSchoolPrompt() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppTheme.primaryBlue.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.school,
              size: 64,
              color: AppTheme.primaryBlue,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Select a School',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.grey[700],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Choose a school to view clubs and activities',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildTabContent(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Column(
        children: [
          // Modern Tab Bar
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: TabBar(
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicator: BoxDecoration(
                color: AppTheme.primaryBlue,
                borderRadius: BorderRadius.circular(12),
              ),
              labelColor: Colors.white,
              unselectedLabelColor: Colors.grey[600],
              labelStyle: const TextStyle(fontWeight: FontWeight.w600),
              unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
              tabs: const [
                Tab(text: 'Clubs', icon: Icon(Icons.groups, size: 20)),
                Tab(text: 'Classes', icon: Icon(Icons.play_circle, size: 20)),
                Tab(text: 'Activities', icon: Icon(Icons.event_note, size: 20)),
                Tab(text: 'Events', icon: Icon(Icons.event, size: 20)),
                Tab(text: 'Members', icon: Icon(Icons.people, size: 20)),
                Tab(text: 'Students', icon: Icon(Icons.school, size: 20)),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Tab Content
          Expanded(
            child: TabBarView(
              children: [
                _buildClubsTab(context),
                _buildRecordedClassesTab(context),
                _buildActivitiesTab(context),
                _buildEventsTab(context),
                _buildMembershipsTab(context),
                _buildStudentsTab(context),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClubsTab(BuildContext context) {
    final selectedCategory = 'All'.obs;
    final selectedClass = Rxn<SchoolClass>();
    final searchQuery = ''.obs;
    final authController = Get.find<AuthController>();
    final schoolController = Get.find<SchoolController>();
    final canManageClubs = authController.hasPermission('CLUBS:CREATE') ||
                          authController.hasPermission('CLUBS:EDIT') ||
                          authController.hasPermission('CLUBS:DELETE');
    
    // Get linked children classes for parent role
    final isParent = authController.user.value?.role == 'parent';
    final myChildrenController = isParent && Get.isRegistered<MyChildrenController>()
        ? Get.find<MyChildrenController>()
        : null;

    // Get unique class info from linked children (both ID and name)
    final linkedChildrenClasses = <String, String>{}; // Map<classId, className>
    if (isParent && myChildrenController != null) {
      for (var child in myChildrenController.children) {
        final className = child['className']?.toString();
        final classId = child['classId']?.toString(); // Get the actual MongoDB ObjectId
        if (className != null && className.isNotEmpty && classId != null && classId.isNotEmpty) {
          linkedChildrenClasses[classId] = className; // Use classId as key, className as value
        }
      }
    }

    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;

    return CustomScrollView(
      slivers: [
        // Header with search and filters
        SliverToBoxAdapter(
          child: Container(
            margin: EdgeInsets.all(isTablet ? 20 : 16),
            padding: EdgeInsets.all(isTablet ? 24 : 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white, AppTheme.primaryBlue.withOpacity(0.05)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.primaryBlue.withOpacity(0.1),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppTheme.primaryBlue, AppTheme.primaryBlue.withOpacity(0.8)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.groups, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        'School Clubs',
                        style: TextStyle(
                          fontSize: isTablet ? 24 : 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryBlue,
                        ),
                      ),
                    ),
                    if (canManageClubs)
                      SizedBox(
                        width: 200,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [AppTheme.primaryBlue, Colors.indigo.shade600],
                                  ),
                                  borderRadius: BorderRadius.circular(12),
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppTheme.primaryBlue.withOpacity(0.3),
                                      blurRadius: 8,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: ElevatedButton.icon(
                                  onPressed: () => _showAddClubDialog(context),
                                  icon: const Icon(Icons.add, size: 18, color: Colors.white),
                                  label: const Text('Add Club', style: TextStyle(color: Colors.white)),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.transparent,
                                    shadowColor: Colors.transparent,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton(
                              onPressed: () => controller.loadClubsData(),
                              icon: const Icon(Icons.refresh),
                              tooltip: 'Refresh Clubs',
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 20),
                
                // Class Filter Dropdown
                Obx(() {
                  // For parents, create available classes from linked children classes
                  List<SchoolClass> availableClasses;
                  if (isParent && linkedChildrenClasses.isNotEmpty) {
                    // Create SchoolClass objects from linked children classes
                    availableClasses = linkedChildrenClasses.entries.map((entry) {
                      return SchoolClass(
                        id: entry.key, // Use actual MongoDB ObjectId as ID
                        name: entry.value, // Use className as display name
                        order: 0, // Default order
                        hasSections: true, // Assume has sections
                        schoolId: schoolController.selectedSchool.value?.id ?? '',
                      );
                    }).toList();
                  } else {
                    // For non-parents, use the loaded classes
                    availableClasses = schoolController.classes;
                  }

                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.3)),
                    ),
                    child: DropdownButtonFormField<SchoolClass>(
                      value: selectedClass.value,
                      decoration: InputDecoration(
                        labelText: 'Filter by Class',
                        prefixIcon: Icon(Icons.class_, color: AppTheme.primaryBlue),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                      hint: Text('All Classes', style: TextStyle(color: Colors.grey.shade600)),
                      dropdownColor: Colors.white,
                      icon: Icon(Icons.arrow_drop_down, color: AppTheme.primaryBlue),
                      items: [
                        DropdownMenuItem<SchoolClass>(
                          value: null,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Icon(Icons.grid_view, color: Colors.grey.shade600, size: 16),
                              ),
                              const SizedBox(width: 12),
                              const Text('All Classes', style: TextStyle(fontWeight: FontWeight.w500)),
                            ],
                          ),
                        ),
                        ...availableClasses.map((schoolClass) {
                          return DropdownMenuItem<SchoolClass>(
                            value: schoolClass,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: AppTheme.primaryBlue.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Icon(Icons.class_, color: AppTheme.primaryBlue, size: 16),
                                ),
                                const SizedBox(width: 12),
                                Flexible(
                                  child: Text(
                                    schoolClass.name,
                                    style: const TextStyle(fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                      onChanged: (SchoolClass? value) {
                        selectedClass.value = value;
                      },
                    ),
                  );
                }),
                
                const SizedBox(height: 16),
                
                // Search Bar
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search clubs...',
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryBlue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.search, color: AppTheme.primaryBlue),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    ),
                    onChanged: (value) => searchQuery.value = value,
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // Category Filters
                // Obx(() => SingleChildScrollView(
                //   scrollDirection: Axis.horizontal,
                //   child: Row(
                //     children: ['All', 'Academic', 'Arts', 'Sports', 'Social'].map((category) {
                //       final isSelected = selectedCategory.value == category;
                //       return Padding(
                //         padding: const EdgeInsets.only(right: 12),
                //         child: Container(
                //           decoration: BoxDecoration(
                //             gradient: isSelected
                //                 ? LinearGradient(
                //                     colors: [AppTheme.primaryBlue, Colors.indigo.shade600],
                //                   )
                //                 : null,
                //             color: isSelected ? null : Colors.white,
                //             borderRadius: BorderRadius.circular(25),
                //             border: Border.all(
                //               color: isSelected ? Colors.black : AppTheme.primaryBlue.withOpacity(0.3),
                //             ),
                //             boxShadow: isSelected ? [
                //               BoxShadow(
                //                 color: AppTheme.primaryBlue.withOpacity(0.3),
                //                 blurRadius: 8,
                //                 offset: const Offset(0, 4),
                //               ),
                //             ] : null,
                //           ),
                //           child: FilterChip(
                //             label: Text(
                //               category,
                //               style: TextStyle(
                //                 color: isSelected ? Colors.black : Colors.black,
                //                 fontWeight: FontWeight.w600,
                //               ),
                //             ),
                //             selected: isSelected,
                //             backgroundColor: Colors.orangeAccent.shade100,
                //             selectedColor: Colors.green.shade200,
                //             checkmarkColor: Colors.transparent,
                //             onSelected: (selected) {
                //               if (selected) selectedCategory.value = category;
                //             },
                //           ),
                //         ),
                //       );
                //     }).toList(),
                //   ),
                // )

              ],
            ),
          ),
        ),
        
        // Clubs Grid/List
        Obx(() {
          if (controller.isLoading.value) {
            return SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: AppTheme.primaryBlue),
                    const SizedBox(height: 16),
                    Text('Loading clubs...', style: TextStyle(color: Colors.grey.shade600)),
                  ],
                ),
              ),
            );
          }

          var filteredClubs = controller.clubs.toList();
          
          // Filter by selected class first
          if (selectedClass.value != null) {
            filteredClubs = controller.getClubsByClass(selectedClass.value!.id);
          }
          
          // Then filter by category
          if (selectedCategory.value != 'All') {
            filteredClubs = filteredClubs.where((club) => club.category == selectedCategory.value).toList();
          }
          
          if (searchQuery.value.isNotEmpty) {
            final query = searchQuery.value.toLowerCase();
            filteredClubs = filteredClubs.where((club) => 
              club.name.toLowerCase().contains(query) ||
              club.description.toLowerCase().contains(query) ||
              club.category.toLowerCase().contains(query)
            ).toList();
          }

          if (filteredClubs.isEmpty) {
            return SliverFillRemaining(
              child: _buildEmptyState(
                icon: Icons.groups,
                title: 'No clubs found',
                subtitle: searchQuery.value.isNotEmpty 
                    ? 'Try adjusting your search terms'
                    : 'Create clubs to get started',
              ),
            );
          }

          return SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _buildModernClubCard(context, filteredClubs[index], canManageClubs, index),
                childCount: filteredClubs.length,
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildClubsGrid(BuildContext context, List<Club> clubs, bool canManageClubs) {
    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: clubs.length,
      itemBuilder: (context, index) {
        return _buildModernClubCard(context, clubs[index], canManageClubs, index);
      },
    );
  }

  Widget _buildClubsList(BuildContext context, List<Club> clubs, bool canManageClubs) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: clubs.length,
      itemBuilder: (context, index) {
        return _buildModernClubCard(context, clubs[index], canManageClubs, index);
      },
    );
  }

  Widget _buildModernClubCard(BuildContext context, Club club, bool canManageClubs, int index) {
    final gradients = [
      AppTheme.TealGradient,
      AppTheme.mathGradient,
      AppTheme.biologyGradient,
      AppTheme.chemistryGradient,
    ];

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        gradient: gradients[index % 4],
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: gradients[index % 4].colors.first.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Get.to(() => ClubDetailView(), arguments: club.id),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        _getCategoryIcon(club.category),
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    const Spacer(),
                    if (canManageClubs)
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.more_vert, color: Colors.white),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        onSelected: (value) {
                          switch (value) {
                            case 'edit':
                              _showEditClubDialog(context, club);
                              break;
                            case 'delete':
                              _showDeleteClubConfirmation(context, club);
                              break;
                            case 'join':
                              _showJoinClubDialog(context, club);
                              break;
                          }
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem(value: 'join', child: Text('Join Club')),
                          const PopupMenuItem(value: 'edit', child: Text('Edit')),
                          const PopupMenuItem(value: 'delete', child: Text('Delete')),
                        ],
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  club.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  club.description,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 16),
                _buildClubInfo(context, club),
                const SizedBox(height: 16),
                _buildOccupancyBar(context, club),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRecordedClassesTab(BuildContext context) {
    final selectedClass = Rxn<SchoolClass>();
    final selectedClub = 'All'.obs;
    final searchQuery = ''.obs;
    final authController = Get.find<AuthController>();
    final schoolController = Get.find<SchoolController>();
    final isParent = authController.user.value?.role == 'parent';
    final canManageClubs = authController.hasPermission('CLUBS:UPLOAD_VIDEO') ||
                          authController.hasPermission('CLUBS:EDIT');

    // Get linked children classes for parent role
    final myChildrenController = isParent && Get.isRegistered<MyChildrenController>()
        ? Get.find<MyChildrenController>()
        : null;

    // Get unique class info from linked children (both ID and name)
    final linkedChildrenClasses = <String, String>{}; // Map<classId, className>
    if (isParent && myChildrenController != null) {
      for (var child in myChildrenController.children) {
        final className = child['className']?.toString();
        final classId = child['classId']?.toString(); // Get the actual MongoDB ObjectId
        if (className != null && className.isNotEmpty && classId != null && classId.isNotEmpty) {
          linkedChildrenClasses[classId] = className; // Use classId as key, className as value
        }
      }
    }

    // Ensure classes are loaded for selected school (only for non-parent users)
    final userRole = Get.find<AuthController>().user.value?.role?.toLowerCase() ?? '';
    final isParentUser = userRole == 'parent';

    if (!isParentUser && schoolController.selectedSchool.value != null &&
        schoolController.classes.isEmpty &&
        !schoolController.isLoading.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        schoolController.getAllClasses(schoolController.selectedSchool.value!.id);
      });
    }
    
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;
    
    return SafeArea(
      child: Column(
        children: [
          // Header with search and filters
          Container(
            margin: EdgeInsets.all(isTablet ? 20 : 16),
            padding: EdgeInsets.all(isTablet ? 24 : 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white, Colors.orange.withOpacity(0.05)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.1),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.orange.shade600, Colors.orange.shade400],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.play_circle, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        'Recorded Classes',
                        style: TextStyle(
                          fontSize: isTablet ? 24 : 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.orange.shade700,
                        ),
                      ),
                    ),
                    if (canManageClubs)
                      Flexible(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Colors.orange.shade600, Colors.orange.shade400],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.orange.withOpacity(0.3),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: ElevatedButton.icon(
                            onPressed: () => _showUploadVideoDialog(context),
                            icon: const Icon(Icons.upload, size: 18, color: Colors.white),
                            label: const Text('Upload Video', style: TextStyle(color: Colors.white)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 20),
                
                // Class Filter Dropdown
                Obx(() {
                  // For parents, create available classes from linked children classes
                  List<SchoolClass> filteredClasses;
                  if (isParent && linkedChildrenClasses.isNotEmpty) {
                    // Create SchoolClass objects from linked children classes
                    filteredClasses = linkedChildrenClasses.entries.map((entry) {
                      return SchoolClass(
                        id: entry.key, // Use actual MongoDB ObjectId as ID
                        name: entry.value, // Use className as display name
                        order: 0, // Default order
                        hasSections: true, // Assume has sections
                        schoolId: schoolController.selectedSchool.value?.id ?? '',
                      );
                    }).toList();
                  } else {
                    // For non-parents, use the loaded classes
                    filteredClasses = schoolController.classes;
                  }

                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.orange.withOpacity(0.3)),
                    ),
                    child: DropdownButtonFormField<SchoolClass>(
                      value: selectedClass.value,
                      decoration: InputDecoration(
                        labelText: 'Filter by Class',
                        prefixIcon: Icon(Icons.class_, color: Colors.orange.shade600),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                      hint: Text('All Classes', style: TextStyle(color: Colors.grey.shade600)),
                      dropdownColor: Colors.white,
                      icon: Icon(Icons.arrow_drop_down, color: Colors.orange.shade600),
                      items: [
                        DropdownMenuItem<SchoolClass>(
                          value: null,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.grey.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Icon(Icons.grid_view, color: Colors.grey.shade600, size: 16),
                              ),
                              const SizedBox(width: 12),
                              const Text('All Classes', style: TextStyle(fontWeight: FontWeight.w500)),
                            ],
                          ),
                        ),
                        ...filteredClasses.map((schoolClass) {
                          return DropdownMenuItem<SchoolClass>(
                            value: schoolClass,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: Colors.orange.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Icon(Icons.class_, color: Colors.orange.shade600, size: 16),
                                ),
                                const SizedBox(width: 12),
                                Flexible(
                                  child: Text(
                                    schoolClass.name,
                                    style: const TextStyle(fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                      onChanged: (SchoolClass? value) {
                        selectedClass.value = value;
                        selectedClub.value = 'All'; // Reset club filter when class changes
                      },
                    ),
                  );
                }),
                
                const SizedBox(height: 16),
                
                // Search Bar
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.orange.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search videos...',
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.orange.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.search, color: Colors.orange.shade600),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    ),
                    onChanged: (value) => searchQuery.value = value,
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // Club Filters (filtered by selected class)
                Obx(() {
                  // Get clubs for selected class
                  List<Club> availableClubs = [];
                  if (selectedClass.value != null) {
                    availableClubs = controller.getClubsByClass(selectedClass.value!.id);
                    
                    for (var club in availableClubs) {
                      
                    }
                  } else {
                    availableClubs = controller.clubs;
                    
                  }
                  
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: ['All', ...availableClubs.map((c) => c.name)].map((clubName) {
                        final isSelected = selectedClub.value == clubName;
                        return Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: isSelected 
                                  ? LinearGradient(
                                      colors: [Colors.orange.shade600, Colors.orange.shade400],
                                    )
                                  : null,
                              color: isSelected ? null : Colors.white,
                              borderRadius: BorderRadius.circular(25),
                              border: Border.all(
                                color: isSelected ? Colors.transparent : Colors.orange.withOpacity(0.3),
                              ),
                              boxShadow: isSelected ? [
                                BoxShadow(
                                  color: Colors.orange.withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 4),
                                ),
                              ] : null,
                            ),
                            child: FilterChip(
                              label: Text(
                                clubName,
                                style: TextStyle(
                                  color: isSelected ? Colors.black : Colors.black,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              selected: isSelected,
                              backgroundColor: Colors.teal.shade100,
                              selectedColor: Colors.transparent,
                              checkmarkColor: Colors.transparent,
                              onSelected: (selected) {
                                selectedClub.value = selected ? clubName : 'All';
                                
                              },
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  );
                }),
              ],
            ),
          ),
          
          // Videos List
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: Colors.orange.shade600),
                      const SizedBox(height: 16),
                      Text('Loading videos...', style: TextStyle(color: Colors.grey.shade600)),
                    ],
                  ),
                );
              }
              
              var filteredClasses = controller.getRecordedClassesByCategory('All');

              // Filter by selected class first
              if (selectedClass.value != null) {
                final classClubs = controller.getClubsByClass(selectedClass.value!.id);
                final classClubIds = classClubs.map((c) => c.id).toList();
                
                filteredClasses = filteredClasses.where((cls) => classClubIds.contains(cls.clubId)).toList();
                
                for (var cls in filteredClasses) {
                  
                }
              }
              
              // Then filter by selected club
              if (selectedClub.value != 'All') {
                filteredClasses = filteredClasses.where((cls) => cls.clubName == selectedClub.value).toList();
                
              }
              
              if (searchQuery.value.isNotEmpty) {
                final query = searchQuery.value.toLowerCase();
                filteredClasses = filteredClasses.where((cls) => 
                  cls.title.toLowerCase().contains(query) ||
                  cls.clubName.toLowerCase().contains(query) ||
                  cls.instructor.toLowerCase().contains(query)
                ).toList();
              }
              
              if (filteredClasses.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.play_circle,
                  title: 'No recorded classes found',
                  subtitle: searchQuery.value.isNotEmpty 
                      ? 'Try adjusting your search terms'
                      : 'Upload videos to get started',
                );
              }
              
              return isLandscape && isTablet
                  ? _buildVideosGrid(context, filteredClasses, canManageClubs)
                  : _buildVideosList(context, filteredClasses, canManageClubs);
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildVideosGrid(BuildContext context, List<RecordedClass> classes, bool canManageClubs) {
    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.4,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: classes.length,
      itemBuilder: (context, index) {
        return _buildModernVideoCard(context, classes[index], canManageClubs);
      },
    );
  }

  Widget _buildVideosList(BuildContext context, List<RecordedClass> classes, bool canManageClubs) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: classes.length,
      itemBuilder: (context, index) {
        return _buildModernVideoCard(context, classes[index], canManageClubs);
      },
    );
  }

  Widget _buildModernVideoCard(BuildContext context, RecordedClass recordedClass, bool canManageClubs) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () => _playVideo(recordedClass),
        borderRadius: BorderRadius.circular(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Video thumbnail
            Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: Stack(
                children: [
                  // Thumbnail content
                  Center(
                    child: recordedClass.videoUrl != null && recordedClass.videoUrl!.isNotEmpty
                        ? const Icon(Icons.play_circle_fill, size: 60, color: Colors.white)
                        : const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.video_library, size: 60, color: Colors.grey),
                              SizedBox(height: 8),
                              Text('Video not available', style: TextStyle(color: Colors.grey)),
                            ],
                          ),
                  ),
                  
                  // Action buttons
                  if (canManageClubs)
                    Positioned(
                      top: 8,
                      right: 8,
                      child: PopupMenuButton<String>(
                        onSelected: (value) {
                          switch (value) {
                            case 'edit':
                              _showEditVideoDialog(context, recordedClass);
                              break;
                            case 'delete':
                              _showDeleteVideoConfirmation(context, recordedClass);
                              break;
                          }
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem(value: 'edit', child: Text('Edit')),
                          const PopupMenuItem(value: 'delete', child: Text('Delete')),
                        ],
                        icon: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Icon(Icons.more_vert, color: Colors.white, size: 16),
                        ),
                      ),
                    ),
                  
                  // Academic year badge
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        recordedClass.academicYear ?? 'N/A',
                        style: const TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Video details
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _getCategoryGradient(recordedClass.category).colors.first,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          recordedClass.level,
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          recordedClass.category,
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    recordedClass.title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    recordedClass.description,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(Icons.school, size: 16, color: Colors.grey[600]),
                      const SizedBox(width: 4),
                      Text(recordedClass.clubName, style: const TextStyle(fontSize: 14)),
                      const SizedBox(width: 16),
                      Icon(Icons.person, size: 16, color: Colors.grey[600]),
                      const SizedBox(width: 4),
                      Text(recordedClass.instructor, style: const TextStyle(fontSize: 14)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.calendar_today, size: 16, color: Colors.grey[600]),
                      const SizedBox(width: 4),
                      Text(recordedClass.uploadDate, style: const TextStyle(fontSize: 14)),
                      const SizedBox(width: 16),
                      Icon(Icons.visibility, size: 16, color: Colors.grey[600]),
                      const SizedBox(width: 4),
                      Text('${recordedClass.viewCount} views', style: const TextStyle(fontSize: 14)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivitiesTab(BuildContext context) {
    final selectedStatus = 'All'.obs;
    final searchQuery = ''.obs;
    
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;
    
    return SafeArea(
      child: Column(
        children: [
          // Header
          Container(
            margin: EdgeInsets.all(isTablet ? 20 : 16),
            padding: EdgeInsets.all(isTablet ? 24 : 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white, Colors.green.withOpacity(0.05)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.1),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.green.shade600, Colors.green.shade400],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.event_note, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        'Club Activities',
                        style: TextStyle(
                          fontSize: isTablet ? 24 : 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.green.shade700,
                        ),
                      ),
                    ),

                  ],
                ),
                const SizedBox(height: 20),
                
                // Search Bar
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.green.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search activities...',
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.green.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.search, color: Colors.green.shade600),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    ),
                    onChanged: (value) => searchQuery.value = value,
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // Status Filters
                Obx(() => SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: ['All', 'Upcoming', 'In Progress', 'Completed'].map((status) {
                      final isSelected = selectedStatus.value == status;
                      return Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: isSelected 
                                ? LinearGradient(
                                    colors: [Colors.green.shade600, Colors.green.shade400],
                                  )
                                : null,
                            color: isSelected ? null : Colors.white,
                            borderRadius: BorderRadius.circular(25),
                            border: Border.all(
                              color: isSelected ? Colors.transparent : Colors.green.withOpacity(0.3),
                            ),
                            boxShadow: isSelected ? [
                              BoxShadow(
                                color: Colors.green.withOpacity(0.3),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                            ] : null,
                          ),
                          child: FilterChip(
                            label: Text(
                              status,
                              style: TextStyle(
                                color: isSelected ? Colors.white : Colors.green.shade700,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            selected: isSelected,
                            backgroundColor: Colors.transparent,
                            selectedColor: Colors.transparent,
                            checkmarkColor: Colors.transparent,
                            onSelected: (selected) {
                              if (selected) selectedStatus.value = status;
                            },
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                )),
              ],
            ),
          ),
          
          // Activities List
          Expanded(
            child: Obx(() {
              var filteredActivities = controller.getActivitiesByStatus(selectedStatus.value);
              if (searchQuery.value.isNotEmpty) {
                final query = searchQuery.value.toLowerCase();
                filteredActivities = filteredActivities.where((activity) => 
                  activity.title.toLowerCase().contains(query) ||
                  activity.clubName.toLowerCase().contains(query)
                ).toList();
              }
              
              if (filteredActivities.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.event_note,
                  title: 'No activities found',
                  subtitle: searchQuery.value.isNotEmpty 
                      ? 'Try adjusting your search terms'
                      : 'Create activities to get started',
                );
              }
              
              return isLandscape && isTablet
                  ? _buildActivitiesGrid(context, filteredActivities)
                  : _buildActivitiesList(context, filteredActivities);
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildActivitiesGrid(BuildContext context, List<Activity> activities) {
    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.5,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: activities.length,
      itemBuilder: (context, index) {
        return _buildModernActivityCard(context, activities[index]);
      },
    );
  }

  Widget _buildActivitiesList(BuildContext context, List<Activity> activities) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: activities.length,
      itemBuilder: (context, index) {
        return _buildModernActivityCard(context, activities[index]);
      },
    );
  }

  Widget _buildModernActivityCard(BuildContext context, Activity activity) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () => _showActivityDetails(context, activity),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _getStatusColor(activity.status).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  _getStatusIcon(activity.status),
                  color: _getStatusColor(activity.status),
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      activity.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Club: ${activity.clubName}',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    Text(
                      '${activity.date} at ${activity.time}',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    Text(
                      '${activity.participantCount} participants',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _getStatusColor(activity.status),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  activity.status,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEventsTab(BuildContext context) {
    final searchQuery = ''.obs;
    
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;
    
    return SafeArea(
      child: Column(
        children: [
          // Header
          Container(
            margin: EdgeInsets.all(isTablet ? 20 : 16),
            padding: EdgeInsets.all(isTablet ? 24 : 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white, Colors.purple.withOpacity(0.05)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.purple.withOpacity(0.1),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.purple.shade600, Colors.purple.shade400],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.event, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        'School Events',
                        style: TextStyle(
                          fontSize: isTablet ? 24 : 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.purple.shade700,
                        ),
                      ),
                    ),

                  ],
                ),
                const SizedBox(height: 20),
                
                // Search Bar
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.purple.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search events...',
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.purple.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.search, color: Colors.purple.shade600),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    ),
                    onChanged: (value) => searchQuery.value = value,
                  ),
                ),
              ],
            ),
          ),
          
          // Events List
          Expanded(
            child: Obx(() {
              var filteredEvents = controller.events.toList();
              if (searchQuery.value.isNotEmpty) {
                final query = searchQuery.value.toLowerCase();
                filteredEvents = filteredEvents.where((event) => 
                  event.title.toLowerCase().contains(query) ||
                  event.description.toLowerCase().contains(query) ||
                  event.category.toLowerCase().contains(query)
                ).toList();
              }
              
              if (filteredEvents.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.event,
                  title: 'No events found',
                  subtitle: searchQuery.value.isNotEmpty 
                      ? 'Try adjusting your search terms'
                      : 'Create events to get started',
                );
              }
              
              return isLandscape && isTablet
                  ? _buildEventsGrid(context, filteredEvents)
                  : _buildEventsList(context, filteredEvents);
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildEventsGrid(BuildContext context, List<Event> events) {
    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.3,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: events.length,
      itemBuilder: (context, index) {
        return _buildModernEventCard(context, events[index]);
      },
    );
  }

  Widget _buildEventsList(BuildContext context, List<Event> events) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: events.length,
      itemBuilder: (context, index) {
        return _buildModernEventCard(context, events[index]);
      },
    );
  }

  Widget _buildMembershipsTab(BuildContext context) {
    final searchQuery = ''.obs;
    
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    final isLandscape = screenSize.width > screenSize.height;
    
    return SafeArea(
      child: Column(
        children: [
          // Header
          Container(
            margin: EdgeInsets.all(isTablet ? 20 : 16),
            padding: EdgeInsets.all(isTablet ? 24 : 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white, Colors.teal.withOpacity(0.05)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.teal.withOpacity(0.1),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.teal.shade600, Colors.teal.shade400],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.people, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        'Club Memberships',
                        style: TextStyle(
                          fontSize: isTablet ? 24 : 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.teal.shade700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                
                // Search Bar
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.teal.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search members...',
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.teal.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.search, color: Colors.teal.shade600),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    ),
                    onChanged: (value) => searchQuery.value = value,
                  ),
                ),
              ],
            ),
          ),
          
          // Memberships List
          Expanded(
            child: Obx(() {
              var filteredMemberships = controller.memberships.toList();
              if (searchQuery.value.isNotEmpty) {
                final query = searchQuery.value.toLowerCase();
                filteredMemberships = filteredMemberships.where((membership) => 
                  membership.studentName.toLowerCase().contains(query) ||
                  membership.clubName.toLowerCase().contains(query) ||
                  membership.role.toLowerCase().contains(query)
                ).toList();
              }
              
              if (filteredMemberships.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.people,
                  title: 'No memberships found',
                  subtitle: searchQuery.value.isNotEmpty 
                      ? 'Try adjusting your search terms'
                      : 'Join clubs to see memberships',
                );
              }
              
              return isLandscape && isTablet
                  ? _buildMembershipsGrid(context, filteredMemberships)
                  : _buildMembershipsList(context, filteredMemberships);
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildMembershipsGrid(BuildContext context, List<Membership> memberships) {
    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 2.0,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: memberships.length,
      itemBuilder: (context, index) {
        return _buildModernMembershipCard(context, memberships[index]);
      },
    );
  }

  Widget _buildMembershipsList(BuildContext context, List<Membership> memberships) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: memberships.length,
      itemBuilder: (context, index) {
        return _buildModernMembershipCard(context, memberships[index]);
      },
    );
  }

  Widget _buildModernMembershipCard(BuildContext context, Membership membership) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: AppTheme.primaryBlue,
              radius: 24,
              child: Text(
                membership.studentName.substring(0, 1).toUpperCase(),
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    membership.studentName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Club: ${membership.clubName}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  Text(
                    'Joined: ${membership.joinDate}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _getRoleColor(membership.role),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                membership.role,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModernEventCard(BuildContext context, Event event) {
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.white, Colors.purple.withOpacity(0.02)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.purple.withOpacity(0.1),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
        border: Border.all(color: Colors.purple.withOpacity(0.1)),
      ),
      child: Padding(
        padding: EdgeInsets.all(isTablet ? 24 : 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.purple.shade600, Colors.purple.shade400],
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    event.category,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const Spacer(),
                PopupMenuButton<String>(
                  icon: Icon(Icons.more_vert, color: Colors.purple.shade600),
                  onSelected: (value) {
                    switch (value) {
                      case 'edit':
                        _showEditEventDialog(context, event);
                        break;
                      case 'delete':
                        _showDeleteEventConfirmation(context, event);
                        break;
                      case 'register':
                        _registerForEvent(event);
                        break;
                    }
                  },
                  itemBuilder: (context) => [
                    if (event.registrationRequired)
                      const PopupMenuItem(value: 'register', child: Text('Register')),
                    const PopupMenuItem(value: 'edit', child: Text('Edit')),
                    const PopupMenuItem(value: 'delete', child: Text('Delete')),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              event.title,
              style: TextStyle(
                fontSize: isTablet ? 20 : 18,
                fontWeight: FontWeight.bold,
                color: Colors.purple.shade700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              event.description,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.purple.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.calendar_today, size: 16, color: Colors.purple.shade600),
                      const SizedBox(width: 8),
                      Text(event.date, style: const TextStyle(fontSize: 14)),
                      const SizedBox(width: 16),
                      Icon(Icons.access_time, size: 16, color: Colors.purple.shade600),
                      const SizedBox(width: 8),
                      Text(event.time, style: const TextStyle(fontSize: 14)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.location_on, size: 16, color: Colors.purple.shade600),
                      const SizedBox(width: 8),
                      Text(event.location, style: const TextStyle(fontSize: 14)),
                      const SizedBox(width: 16),
                      Icon(Icons.group, size: 16, color: Colors.purple.shade600),
                      const SizedBox(width: 8),
                      Text(event.organizer, style: const TextStyle(fontSize: 14)),
                    ],
                  ),
                ],
              ),
            ),
            if (event.registrationRequired) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: LinearProgressIndicator(
                      value: event.registrationRate,
                      backgroundColor: Colors.grey.shade200,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        event.isFull ? Colors.red : Colors.purple.shade600,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '${event.currentParticipants}/${event.maxParticipants}',
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return SingleChildScrollView(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 64,
                color: Colors.grey[400],
              ),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(
                subtitle,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUpgradeRequiredWidget(BuildContext context, String featureName) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.orange.shade100,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.lock_outline,
                size: 64,
                color: Colors.orange.shade600,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Upgrade Required',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Your current plan does not include the $featureName module. Please contact your correspondent to upgrade.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () { /* Optional: Navigate to pricing or contact support */
                Navigator.push(context, MaterialPageRoute(builder: (_)=>SubscriptionManagementView()));},
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange.shade600,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text('View Plans'),
            ),
          ],
        ),
      ),
    );
  }

  // Helper methods and dialogs remain the same as original implementation
  Widget _buildClubInfo(BuildContext context, Club club) {
    return Column(
      children: [
        Row(
          children: [
            const Icon(Icons.person, size: 16, color: Colors.white70),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Coordinator: ${club.coordinator}',
                style: const TextStyle(color: Colors.white70, fontSize: 14),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            const Icon(Icons.schedule, size: 16, color: Colors.white70),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '${club.meetingDay} at ${club.meetingTime}',
                style: const TextStyle(color: Colors.white70, fontSize: 14),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            const Icon(Icons.location_on, size: 16, color: Colors.white70),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                club.location,
                style: const TextStyle(color: Colors.white70, fontSize: 14),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildOccupancyBar(BuildContext context, Club club) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Members',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            Text(
              '${club.memberCount}/${club.maxMembers}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 8,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: Colors.white.withOpacity(0.3),
          ),
          child: FractionallySizedBox(
            widthFactor: club.occupancyRate,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Gradient _getCategoryGradient(String category) {
    switch (category) {
      case 'Academic':
        return AppTheme.primaryGradient;
      case 'Arts':
        return AppTheme.geographyGradient;
      case 'Sports':
        return AppTheme.successGradient;
      case 'Social':
        return AppTheme.warningGradient;
      default:
        return AppTheme.primaryGradient;
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Academic':
        return Icons.school;
      case 'Arts':
        return Icons.palette;
      case 'Sports':
        return Icons.sports;
      case 'Social':
        return Icons.people;
      default:
        return Icons.group;
    }
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Upcoming':
        return AppTheme.primaryBlue;
      case 'In Progress':
        return Colors.orange;
      case 'Completed':
        return Colors.green;
      default:
        return AppTheme.primaryBlue;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'Upcoming':
        return Icons.schedule;
      case 'In Progress':
        return Icons.play_circle;
      case 'Completed':
        return Icons.check_circle;
      default:
        return Icons.event;
    }
  }

  Color _getRoleColor(String role) {
    switch (role) {
      case 'President':
        return Colors.red;
      case 'Secretary':
        return Colors.orange;
      case 'Member':
        return AppTheme.primaryBlue;
      default:
        return AppTheme.primaryBlue;
    }
  }

  void _showAddClubDialog(BuildContext context) {
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();
    final coordinatorController = TextEditingController();
    final locationController = TextEditingController();
    final maxMembersController = TextEditingController(text: '30');
    final selectedCategory = 'Academic'.obs;
    
    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Add New Club', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.primaryBlue)),
              const SizedBox(height: 20),
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Club Name',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              TextField(
                controller: coordinatorController,
                decoration: InputDecoration(
                  labelText: 'Coordinator',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              Obx(() => DropdownButtonFormField<String>(
                value: selectedCategory.value,
                decoration: InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                items: ['Academic', 'Arts', 'Sports', 'Social']
                    .map((category) => DropdownMenuItem(value: category, child: Text(category)))
                    .toList(),
                onChanged: (value) => selectedCategory.value = value!,
              )),
              const SizedBox(height: 16),
              TextField(
                controller: locationController,
                decoration: InputDecoration(
                  labelText: 'Location',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: maxMembersController,
                decoration: InputDecoration(
                  labelText: 'Max Members',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Get.back(),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        if (nameController.text.isNotEmpty) {
                          final schoolController = Get.find<SchoolController>();
                          final schoolId = schoolController.selectedSchool.value?.id ?? '';
                          
                          final newClub = Club(
                            id: DateTime.now().millisecondsSinceEpoch.toString(),
                            name: nameController.text,
                            description: descriptionController.text,
                            isActive: true,
                            createdAt: DateTime.now().toIso8601String(),
                            updatedAt: DateTime.now().toIso8601String(),
                            schoolId: schoolId,
                            category: selectedCategory.value,
                            coordinator: coordinatorController.text,
                            meetingDay: 'Monday', // Default value
                            meetingTime: '3:00 PM', // Default value
                            location: locationController.text,
                            memberCount: 0,
                            maxMembers: int.tryParse(maxMembersController.text) ?? 30,
                          );
                          controller.addClub(newClub);
                          Get.back();
                        }
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryBlue),
                      child: const Text('Add Club', style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // void _showUploadVideoDialog(BuildContext context) {
  //   final titleController = TextEditingController();
  //   final topicController = TextEditingController();
  //   final selectedLevel = 'Beginner'.obs;
  //   final selectedClub = Rxn<Club>();
  //
  //   Get.dialog(
  //     Dialog(
  //       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  //       child: Container(
  //         padding: const EdgeInsets.all(24),
  //         child: Column(
  //           mainAxisSize: MainAxisSize.min,
  //           children: [
  //             Text('Upload Video', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.orange.shade600)),
  //             const SizedBox(height: 20),
  //             TextField(
  //               controller: titleController,
  //               decoration: InputDecoration(
  //                 labelText: 'Video Title',
  //                 border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
  //               ),
  //             ),
  //             const SizedBox(height: 16),
  //             TextField(
  //               controller: topicController,
  //               decoration: InputDecoration(
  //                 labelText: 'Topic',
  //                 border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
  //               ),
  //             ),
  //             const SizedBox(height: 16),
  //             Obx(() => DropdownButtonFormField<String>(
  //               value: selectedLevel.value,
  //               decoration: InputDecoration(
  //                 labelText: 'Level',
  //                 border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
  //               ),
  //               items: ['Beginner', 'Intermediate', 'Advanced']
  //                   .map((level) => DropdownMenuItem(value: level, child: Text(level)))
  //                   .toList(),
  //               onChanged: (value) => selectedLevel.value = value!,
  //             )),
  //             const SizedBox(height: 16),
  //             Obx(() => DropdownButtonFormField<Club>(
  //               value: selectedClub.value,
  //               decoration: InputDecoration(
  //                 labelText: 'Club',
  //                 border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
  //               ),
  //               items: controller.clubs
  //                   .map((club) => DropdownMenuItem(value: club, child: Text(club.name)))
  //                   .toList(),
  //               onChanged: (value) => selectedClub.value = value,
  //             )),
  //             const SizedBox(height: 16),
  //             Container(
  //               width: double.infinity,
  //               height: 50,
  //               decoration: BoxDecoration(
  //                 border: Border.all(color: Colors.grey),
  //                 borderRadius: BorderRadius.circular(12),
  //               ),
  //               child: TextButton.icon(
  //                 onPressed: () async {
  //                   final result = await FilePicker.platform.pickFiles(
  //                     type: FileType.video,
  //                     allowMultiple: false,
  //                   );
  //                   if (result != null) {
  //                     Get.snackbar('Success', 'Video selected: ${result.files.first.name}');
  //                   }
  //                 },
  //                 icon: const Icon(Icons.video_library),
  //                 label: const Text('Select Video File'),
  //               ),
  //             ),
  //             const SizedBox(height: 24),
  //             Row(
  //               children: [
  //                 Expanded(
  //                   child: TextButton(
  //                     onPressed: () => Get.back(),
  //                     child: const Text('Cancel'),
  //                   ),
  //                 ),
  //                 const SizedBox(width: 16),
  //                 Expanded(
  //                   child: ElevatedButton(
  //                     onPressed: () {
  //                       if (titleController.text.isNotEmpty && selectedClub.value != null) {
  //                         controller.uploadVideo(
  //                           title: titleController.text,
  //                           topic: topicController.text,
  //                           level: selectedLevel.value,
  //                           clubId: selectedClub.value!.id,
  //                         );
  //                         Get.back();
  //                       }
  //                     },
  //                     style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade600),
  //                     child: const Text('Upload', style: TextStyle(color: Colors.white)),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           ],
  //         ),
  //       ),
  //     ),
  //   );
  // }

  // void _showAddClubDialog(BuildContext context) {
  //   _showClubForm(context, null);
  // }

  void _showEditClubDialog(BuildContext context, Club club) {
    _showClubForm(context, club);
  }

  void _showClubForm(BuildContext context, Club? club) {
    final nameController = TextEditingController(text: club?.name ?? '');
    final descriptionController = TextEditingController(text: club?.description ?? '');
    final coordinatorController = TextEditingController(text: club?.coordinator ?? '');
    final locationController = TextEditingController(text: club?.location ?? '');
    final maxMembersController = TextEditingController(text: club?.maxMembers.toString() ?? '30');
    final selectedCategory = (club?.category ?? 'Academic').obs;
    final selectedDay = (club?.meetingDay ?? 'Monday').obs;
    final selectedTime = (club?.meetingTime ?? '3:00 PM').obs;
    final selectedThumbnailPath = ''.obs;
    final selectedThumbnailName = ''.obs;

    // For editing existing club, show thumbnail update first
    if (club != null) {
      _showThumbnailUpdateDialog(context, club, () {
        // After thumbnail update (or skip), show the text editing dialog
        _showClubTextEditDialog(
          context,
          club,
          nameController,
          descriptionController,
          coordinatorController,
          locationController,
          maxMembersController,
          selectedCategory,
          selectedDay,
          selectedTime,
        );
      });
    } else {
      // For new club creation, show everything in one dialog
      _showClubCreationDialog(
        context,
        nameController,
        descriptionController,
        coordinatorController,
        locationController,
        maxMembersController,
        selectedCategory,
        selectedDay,
        selectedTime,
        selectedThumbnailPath,
        selectedThumbnailName,
      );
    }
  }

  void _showThumbnailUpdateDialog(BuildContext context, Club club, VoidCallback onContinue) {
    final selectedThumbnailPath = ''.obs;
    final selectedThumbnailName = ''.obs;

    Get.dialog(
      AlertDialog(
        title: const Text('Update Club Thumbnail'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Would you like to update the club thumbnail?', textAlign: TextAlign.center),
              const SizedBox(height: 20),
              if (club.thumbnailUrl != null) ...[
                Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: DecorationImage(
                      image: NetworkImage(club.thumbnailUrl!),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Current thumbnail', style: TextStyle(fontSize: 12, color: Colors.grey)),
                const SizedBox(height: 16),
              ],
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () async {
                    try {
                      final result = await FilePicker.platform.pickFiles(
                        type: FileType.image,
                        allowMultiple: false,
                      );

                      if (result != null && result.files.isNotEmpty) {
                        final file = result.files.first;

                        if (file.path != null) {
                          final originalFile = File(file.path!);
                          if (await originalFile.exists()) {
                            final fileSize = await originalFile.length();
                            final fileSizeMB = fileSize / 1024 / 1024;

                            if (fileSizeMB > 5) {
                              Get.snackbar('Warning', 'Image size is ${fileSizeMB.toStringAsFixed(1)}MB. Large images may affect performance.');
                            }

                            selectedThumbnailPath.value = file.path!;
                            selectedThumbnailName.value = file.name;
                            
                          } else {
                            Get.snackbar('Error', 'Selected image file is not accessible');
                          }
                        } else if (file.bytes != null) {
                          Get.snackbar('Error', 'Device storage full. Please free up space and try again.');
                        } else {
                          Get.snackbar('Error', 'Unable to access selected image');
                        }
                      }
                    } catch (e) {
                      
                      Get.snackbar('Error', 'Failed to select image file');
                    }
                  },
                  icon: const Icon(Icons.image),
                  label: Obx(() => Text(selectedThumbnailName.value.isEmpty
                      ? 'Select New Thumbnail'
                      : 'Replace Image')),
                ),
              ),
              Obx(() => selectedThumbnailName.value.isNotEmpty
                  ? Container(
                margin: const EdgeInsets.only(top: 16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.check_circle, color: Colors.green, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        selectedThumbnailName.value,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              )
                  : const SizedBox.shrink()),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Get.back();
              onContinue(); // Continue to text editing
            },
            child: const Text('Skip'),
          ),
          Obx(() => ElevatedButton(
            onPressed: selectedThumbnailPath.value.isNotEmpty ? () async {
              try {
                final clubController = Get.find<ClubController>();
                await clubController.updateClubThumbnail(club.id, selectedThumbnailPath.value);
                Get.back();
                onContinue(); // Continue to text editing
              } catch (e) {
                
                Get.snackbar('Error', 'Failed to update thumbnail');
              }
            } : null,
            child: const Text('Update Thumbnail'),
          )),
        ],
      ),
    );
  }

  void _showClubTextEditDialog(
      BuildContext context,
      Club club,
      TextEditingController nameController,
      TextEditingController descriptionController,
      TextEditingController coordinatorController,
      TextEditingController locationController,
      TextEditingController maxMembersController,
      RxString selectedCategory,
      RxString selectedDay,
      RxString selectedTime,
      ) {
    final schoolController = Get.find<SchoolController>();
    final selectedClass = Rxn<SchoolClass>();
    
    // Load classes when dialog opens
    if (schoolController.selectedSchool.value != null) {
      schoolController.getAllClasses(schoolController.selectedSchool.value!.id);
    }
    
    // Try to find the current class if club has classId
    // Note: You'll need to add classId to the Club model if not already present
    
    Get.dialog(
      AlertDialog(
        title: const Text('Edit Club Details'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Club Name'),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(labelText: 'Description'),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                // Class Dropdown
                Obx(() => DropdownButtonFormField<SchoolClass>(
                  value: selectedClass.value,
                  decoration: const InputDecoration(
                    labelText: 'Select Class',
                    border: OutlineInputBorder(),
                  ),
                  hint: const Text('Choose a class'),
                  items: schoolController.classes.map((schoolClass) {
                    return DropdownMenuItem<SchoolClass>(
                      value: schoolClass,
                      child: Text('${schoolClass.name} (${schoolClass.studentCount ?? 0} students)'),
                    );
                  }).toList(),
                  onChanged: (SchoolClass? value) {
                    selectedClass.value = value;
                  },
                )),
                const SizedBox(height: 16),
                TextField(
                  controller: coordinatorController,
                  decoration: const InputDecoration(labelText: 'Coordinator'),
                ),
                const SizedBox(height: 16),
                Obx(() => DropdownButtonFormField<String>(
                  value: selectedCategory.value,
                  decoration: const InputDecoration(labelText: 'Category'),
                  items: ['Academic', 'Arts', 'Sports', 'Social']
                      .map((category) => DropdownMenuItem(value: category, child: Text(category)))
                      .toList(),
                  onChanged: (value) => selectedCategory.value = value!,
                )),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Obx(() => DropdownButtonFormField<String>(
                        value: selectedDay.value,
                        decoration: const InputDecoration(labelText: 'Meeting Day'),
                        items: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
                            .map((day) => DropdownMenuItem(value: day, child: Text(day)))
                            .toList(),
                        onChanged: (value) => selectedDay.value = value!,
                      )),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Obx(() => TextField(
                        controller: TextEditingController(text: selectedTime.value),
                        decoration: const InputDecoration(labelText: 'Meeting Time'),
                        onChanged: (value) => selectedTime.value = value,
                      )),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: locationController,
                  decoration: const InputDecoration(labelText: 'Location'),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: maxMembersController,
                  decoration: const InputDecoration(labelText: 'Max Members'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.trim().isEmpty) {
                Get.snackbar('Error', 'Club name is required');
                return;
              }
              if (selectedClass.value == null) {
                Get.snackbar('Error', 'Please select a class');
                return;
              }
              
              final schoolController = Get.find<SchoolController>();
              final schoolId = schoolController.selectedSchool.value?.id ?? '';

              final updatedClub = Club(
                id: club.id,
                name: nameController.text,
                description: descriptionController.text,
                thumbnailUrl: club.thumbnailUrl,
                isActive: club.isActive,
                createdAt: club.createdAt,
                updatedAt: DateTime.now().toIso8601String(),
                schoolId: schoolId,
                category: selectedCategory.value,
                coordinator: coordinatorController.text,
                meetingDay: selectedDay.value,
                meetingTime: selectedTime.value,
                location: locationController.text,
                memberCount: club.memberCount,
                maxMembers: int.tryParse(maxMembersController.text) ?? 30,
              );

              try {
                await controller.updateClub(updatedClub, classId: selectedClass.value!.id);
                Get.back(); // Close dialog after successful update
              } catch (e) {
                
                Get.snackbar('Error', 'Failed to update club');
              }
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  void _showClubCreationDialog(
      BuildContext context,
      TextEditingController nameController,
      TextEditingController descriptionController,
      TextEditingController coordinatorController,
      TextEditingController locationController,
      TextEditingController maxMembersController,
      RxString selectedCategory,
      RxString selectedDay,
      RxString selectedTime,
      RxString selectedThumbnailPath,
      RxString selectedThumbnailName,
      ) {
    final schoolController = Get.find<SchoolController>();
    final selectedClass = Rxn<SchoolClass>();
    
    // Load classes when dialog opens
    if (schoolController.selectedSchool.value != null) {
      schoolController.getAllClasses(schoolController.selectedSchool.value!.id);
    }

    Get.dialog(
      AlertDialog(
        title: const Text('Create Club'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Club Name'),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(labelText: 'Description'),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                // Class Dropdown
                Obx(() => DropdownButtonFormField<SchoolClass>(
                  value: selectedClass.value,
                  decoration: const InputDecoration(
                    labelText: 'Select Class',
                    border: OutlineInputBorder(),
                  ),
                  hint: const Text('Choose a class'),
                  items: schoolController.classes.map((schoolClass) {
                    return DropdownMenuItem<SchoolClass>(
                      value: schoolClass,
                      child: Text('${schoolClass.name} (${schoolClass.studentCount ?? 0} students)'),
                    );
                  }).toList(),
                  onChanged: (SchoolClass? value) {
                    selectedClass.value = value;
                  },
                )),
                const SizedBox(height: 16),
                TextField(
                  controller: coordinatorController,
                  decoration: const InputDecoration(labelText: 'Coordinator'),
                ),
                const SizedBox(height: 16),
                Obx(() => DropdownButtonFormField<String>(
                  value: selectedCategory.value,
                  decoration: const InputDecoration(labelText: 'Category'),
                  items: ['Academic', 'Arts', 'Sports', 'Social']
                      .map((category) => DropdownMenuItem(value: category, child: Text(category)))
                      .toList(),
                  onChanged: (value) => selectedCategory.value = value!,
                )),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Obx(() => DropdownButtonFormField<String>(
                        value: selectedDay.value,
                        decoration: const InputDecoration(labelText: 'Meeting Day'),
                        items: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
                            .map((day) => DropdownMenuItem(value: day, child: Text(day)))
                            .toList(),
                        onChanged: (value) => selectedDay.value = value!,
                      )),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Obx(() => TextField(
                        controller: TextEditingController(text: selectedTime.value),
                        decoration: const InputDecoration(labelText: 'Meeting Time'),
                        onChanged: (value) => selectedTime.value = value,
                      )),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: locationController,
                  decoration: const InputDecoration(labelText: 'Location'),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: maxMembersController,
                  decoration: const InputDecoration(labelText: 'Max Members'),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 16),
                const Text('Club Thumbnail (Optional)', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      try {
                        final result = await FilePicker.platform.pickFiles(
                          type: FileType.image,
                          allowMultiple: false,
                        );

                        if (result != null && result.files.isNotEmpty) {
                          final file = result.files.first;

                          if (file.path != null) {
                            final originalFile = File(file.path!);
                            if (await originalFile.exists()) {
                              final fileSize = await originalFile.length();
                              final fileSizeMB = fileSize / 1024 / 1024;

                              if (fileSizeMB > 5) {
                                Get.snackbar('Warning', 'Image size is ${fileSizeMB.toStringAsFixed(1)}MB. Large images may affect performance.');
                              }

                              selectedThumbnailPath.value = file.path!;
                              selectedThumbnailName.value = file.name;
                              
                            } else {
                              Get.snackbar('Error', 'Selected image file is not accessible');
                            }
                          } else if (file.bytes != null) {
                            Get.snackbar('Error', 'Device storage full. Please free up space and try again.');
                          } else {
                            Get.snackbar('Error', 'Unable to access selected image');
                          }
                        }
                      } catch (e) {
                        
                        Get.snackbar('Error', 'Failed to select image file');
                      }
                    },
                    icon: const Icon(Icons.image),
                    label: Obx(() => Text(selectedThumbnailName.value.isEmpty
                        ? 'Select Thumbnail Image'
                        : 'Replace Image')),
                  ),
                ),
                Obx(() => selectedThumbnailName.value.isNotEmpty
                    ? Container(
                  margin: const EdgeInsets.only(top: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.green.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.check_circle, color: Colors.green, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          selectedThumbnailName.value,
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                )
                    : const SizedBox.shrink()),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.trim().isEmpty) {
                Get.snackbar('Error', 'Club name is required');
                return;
              }
              if (selectedClass.value == null) {
                Get.snackbar('Error', 'Please select a class');
                return;
              }
              
              final schoolController = Get.find<SchoolController>();
              final schoolId = schoolController.selectedSchool.value?.id ?? '';

              final newClub = Club(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                name: nameController.text,
                description: descriptionController.text,
                thumbnailUrl: null,
                isActive: true,
                createdAt: DateTime.now().toIso8601String(),
                updatedAt: DateTime.now().toIso8601String(),
                schoolId: schoolId,
                category: selectedCategory.value,
                coordinator: coordinatorController.text,
                meetingDay: selectedDay.value,
                meetingTime: selectedTime.value,
                location: locationController.text,
                memberCount: 0,
                maxMembers: int.tryParse(maxMembersController.text) ?? 30,
              );

              try {
                await controller.addClub(
                  newClub, 
                  thumbnailPath: selectedThumbnailPath.value.isNotEmpty ? selectedThumbnailPath.value : null,
                  classId: selectedClass.value!.id,
                );
                Get.back();
              } catch (e) {
                
                Get.snackbar('Error', 'Failed to create club');
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _showDeleteClubConfirmation(BuildContext context, Club club) {
    Get.dialog(
      AlertDialog(
        title: const Text('Delete Club'),
        content: Text('Are you sure you want to delete ${club.name}?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              controller.deleteClub(club.id);
              Get.back();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showJoinClubDialog(BuildContext context, Club club) {
    final studentNameController = TextEditingController();

    Get.dialog(
      AlertDialog(
        title: Text('Join ${club.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: studentNameController,
              decoration: const InputDecoration(labelText: 'Student Name'),
            ),
            const SizedBox(height: 16),
            Text('Available spots: ${club.maxMembers - club.memberCount}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: club.isFull ? null : () {
              if (studentNameController.text.trim().isEmpty) {
                Get.snackbar('Error', 'Please enter student name');
                return;
              }

              controller.joinClub(
                DateTime.now().millisecondsSinceEpoch.toString(),
                studentNameController.text.trim(),
                club.id,
              );
              Get.back(); // Close dialog after joining
            },
            child: Text(club.isFull ? 'Club Full' : 'Join'),
          ),
        ],
      ),
    );
  }

  void _showActivityDetails(BuildContext context, Activity activity) {
    Get.dialog(
      AlertDialog(
        title: Text(activity.title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Club: ${activity.clubName}'),
            Text('Date: ${activity.date}'),
            Text('Time: ${activity.time}'),
            Text('Location: ${activity.location}'),
            Text('Status: ${activity.status}'),
            Text('Participants: ${activity.participantCount}'),
            const SizedBox(height: 16),
            Text(activity.description),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showAddEventDialog(BuildContext context) {
    // Implementation for adding event
    Get.snackbar('Info', 'Add Event dialog would be implemented here',backgroundColor: Colors.amber,colorText: Colors.white);
  }

  void _showEditEventDialog(BuildContext context, Event event) {
    // Implementation for editing event
    Get.snackbar('Info', 'Edit Event dialog would be implemented here',backgroundColor: Colors.amber,colorText: Colors.white);
  }

  void _showDeleteEventConfirmation(BuildContext context, Event event) {
    Get.dialog(
      AlertDialog(
        title: const Text('Delete Event'),
        content: Text('Are you sure you want to delete ${event.title}?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              controller.deleteEvent(event.id);
              Get.back();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _registerForEvent(Event event) {
    if (event.isFull) {
      Get.snackbar('Error', 'Event is full');
    } else {
      Get.snackbar('Success', 'Successfully registered for ${event.title}');
    }
  }

  void _showUploadVideoDialog(BuildContext context) {
    final selectedVideoPath = ''.obs;
    final selectedVideoName = ''.obs;

    Get.dialog(
      AlertDialog(
        title: const Text('Upload Video'),
        content: SizedBox(
          width: double.maxFinite,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.6,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        try {
                          final result = await FilePicker.platform.pickFiles(
                            type: FileType.video,
                            allowMultiple: false,
                          );

                          if (result != null && result.files.isNotEmpty) {
                            final file = result.files.first;

                            // Use original file path directly to avoid storage issues
                            if (file.path != null) {
                              final originalFile = File(file.path!);
                              if (await originalFile.exists()) {
                                final fileSize = await originalFile.length();
                                final fileSizeMB = fileSize / 1024 / 1024;

                                // Warn about large files
                                if (fileSizeMB > 50) {
                                  Get.snackbar('Large File Warning',
                                      'File size: ${fileSizeMB.toStringAsFixed(1)}MB. Large files may fail to upload due to network timeouts.');
                                }

                                selectedVideoPath.value = file.path!;
                                selectedVideoName.value = file.name;

                              } else {
                                Get.snackbar('Error', 'Selected file is not accessible');
                              }
                            } else if (file.bytes != null) {
                              Get.snackbar('Error', 'Device storage full. Please free up space and try again.');
                            } else {
                              Get.snackbar('Error', 'Unable to access selected file');
                            }
                          }
                        } catch (e) {
                          
                          if (e.toString().contains('No space left on device')) {
                            Get.snackbar('Storage Full', 'Device storage is full. Please free up space and try again.');
                          } else {
                            Get.snackbar('Error', 'Failed to select video file');
                          }
                        }
                      },
                      icon: const Icon(Icons.video_file),
                      label: Obx(() => Text(selectedVideoName.value.isEmpty
                          ? 'Select Video File'
                          : 'Replace Video')),
                    ),
                  ),
                  Obx(() => selectedVideoName.value.isNotEmpty
                      ? Container(
                    margin: const EdgeInsets.only(top: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.green.withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.check_circle, color: Colors.green, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                selectedVideoName.value,
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          height: 150,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              // Show fullscreen preview
                              Get.dialog(
                                Dialog.fullscreen(
                                  child: Scaffold(
                                    backgroundColor: Colors.black,
                                    appBar: AppBar(
                                      backgroundColor: Colors.transparent,
                                      iconTheme: const IconThemeData(color: Colors.white),
                                    ),
                                    body: const Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.play_circle_fill, size: 100, color: Colors.white),
                                          SizedBox(height: 16),
                                          Text('Video Preview', style: TextStyle(color: Colors.white, fontSize: 20)),
                                          SizedBox(height: 8),
                                          Text('Video player would show here', style: TextStyle(color: Colors.white70)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                            child: const Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.play_circle_fill, size: 50, color: Colors.white),
                                  SizedBox(height: 8),
                                  Text('Video Preview', style: TextStyle(color: Colors.white)),
                                  SizedBox(height: 4),
                                  Text('Tap to play in fullscreen', style: TextStyle(color: Colors.white70, fontSize: 12)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                      : const SizedBox.shrink()),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          Obx(() {
            return ElevatedButton(
              onPressed: selectedVideoPath.value.isNotEmpty ? () {
                Get.back();
                _showVideoUploadForm(context, selectedVideoPath.value);
              } : null,
              child: const Text('Continue'),
            );
          }),
        ],
      ),
    );
  }

  void _showVideoUploadForm(BuildContext context, String videoPath) {
    final titleController = TextEditingController();
    final topicController = TextEditingController();
    final academicYearController = TextEditingController(text: '2025-2026');
    final selectedLevel = 'Beginner'.obs;
    final selectedClub = Rxn<Club>();

    Get.dialog(
      AlertDialog(
        title: const Text('Video Details'),
        content: SizedBox(
          width: double.maxFinite,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.6,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: 'Video Title',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: topicController,
                    decoration: const InputDecoration(
                      labelText: 'Topic',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: academicYearController,
                    decoration: const InputDecoration(
                      labelText: 'Academic Year',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Obx(() => DropdownButtonFormField<String>(
                    value: selectedLevel.value,
                    decoration: const InputDecoration(
                      labelText: 'Level',
                      border: OutlineInputBorder(),
                    ),
                    items: ['Beginner', 'Intermediate', 'Advanced', 'general']
                        .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                        .toList(),
                    onChanged: (value) => selectedLevel.value = value!,
                  )),
                  const SizedBox(height: 16),
                  Obx(() => DropdownButtonFormField<Club>(
                    value: selectedClub.value,
                    decoration: const InputDecoration(
                      labelText: 'Club',
                      border: OutlineInputBorder(),
                    ),
                    items: controller.clubs
                        .map((club) => DropdownMenuItem(value: club, child: Text(club.name)))
                        .toList(),
                    onChanged: (value) => selectedClub.value = value,
                  )),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          Obx(() {
            final titleNotEmpty = titleController.text.isNotEmpty;
            final clubSelected = selectedClub.value != null;
            return ElevatedButton(
              onPressed: (titleNotEmpty && clubSelected) ? () async {
                final clubController = Get.find<ClubController>();
                final schoolController = Get.find<SchoolController>();
                final schoolId = schoolController.selectedSchool.value?.id ?? '';

                if (schoolId.isEmpty) {
                  Get.snackbar('Error', 'Please select a school first');
                  return;
                }

                // Show loading dialog
                Get.dialog(
                  AlertDialog(
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const CircularProgressIndicator(),
                        const SizedBox(height: 16),
                        const Text('Uploading video...'),
                        const SizedBox(height: 8),
                        Text('This may take a few minutes',
                            style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                      ],
                    ),
                  ),
                  barrierDismissible: false,
                );

                try {
                  await clubController.uploadClubVideo(
                    schoolId: schoolId,
                    clubId: selectedClub.value!.id,
                    title: titleController.text,
                    topic: topicController.text,
                    level: selectedLevel.value,
                    academicYear: academicYearController.text.trim(),
                    videoPath: videoPath,
                  );
                  // Close dialogs safely
                  Navigator.of(Get.context!).pop(); // Close loading dialog
                  Navigator.of(Get.context!).pop(); // Close form dialog
                } catch (e) {
                  // Close loading dialog safely
                  Navigator.of(Get.context!).pop();
                }
              } : null,
              child: const Text('Upload'),
            );
          }),
        ],
      ),
    );
  }

  // void _showAddActivityDialog(BuildContext context) {
  //   Get.snackbar('Info', 'Add Activity dialog would be implemented here');
  // }
  //
  // void _showActivityDetails(BuildContext context, Activity activity) {
  //   Get.snackbar('Info', 'Activity details would be shown here');
  // }
  //
  // void _showAddEventDialog(BuildContext context) {
  //   Get.snackbar('Info', 'Add Event dialog would be implemented here');
  // }
  //
  // void _showEditEventDialog(BuildContext context, Event event) {
  //   Get.snackbar('Info', 'Edit Event dialog would be implemented here');
  // }
  //
  // void _showDeleteEventConfirmation(BuildContext context, Event event) {
  //   Get.snackbar('Info', 'Delete Event confirmation would be implemented here');
  // }
  //
  // void _registerForEvent(Event event) {
  //   Get.snackbar('Info', 'Event registration would be implemented here');
  // }

  void _showEditVideoDialog(BuildContext context, RecordedClass video) {
    final titleController = TextEditingController(text: video.title);
    final topicController = TextEditingController(text: video.category);
    final validLevels = ['Beginner', 'Intermediate', 'Advanced', 'general'];
    final selectedLevel = (validLevels.contains(video.level) ? video.level : 'Beginner').obs;
    final selectedVideoPath = ''.obs;
    final selectedVideoName = ''.obs;

    Get.dialog(
      AlertDialog(
        title: const Text('Edit Video'),
        content: SizedBox(
          width: double.maxFinite,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.7,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: 'Video Title',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: topicController,
                    decoration: const InputDecoration(
                      labelText: 'Topic',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Obx(() => DropdownButtonFormField<String>(
                    value: selectedLevel.value,
                    decoration: const InputDecoration(
                      labelText: 'Level',
                      border: OutlineInputBorder(),
                    ),
                    items: validLevels
                        .map((level) => DropdownMenuItem(value: level, child: Text(level)))
                        .toList(),
                    onChanged: (value) => selectedLevel.value = value!,
                  )),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 8),
                  Text('Replace Video File (Optional)',
                      style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        try {
                          final result = await FilePicker.platform.pickFiles(
                            type: FileType.video,
                            allowMultiple: false,
                          );

                          if (result != null && result.files.isNotEmpty) {
                            final file = result.files.first;
                            if (file.path != null && await File(file.path!).exists()) {
                              selectedVideoPath.value = file.path!;
                              selectedVideoName.value = file.name;
                              
                            } else if (file.bytes != null) {
                              // If path is not available, save bytes to temp file
                              final tempDir = Directory.systemTemp;
                              final tempFile = File('${tempDir.path}/${file.name}');
                              await tempFile.writeAsBytes(file.bytes!);
                              selectedVideoPath.value = tempFile.path;
                              selectedVideoName.value = file.name;
                              
                            } else {
                              Get.snackbar('Error', 'Unable to access selected file');
                            }
                          }
                        } catch (e) {
                          
                          Get.snackbar('Error', 'Failed to select video file');
                        }
                      },
                      icon: const Icon(Icons.video_file),
                      label: Obx(() => Text(selectedVideoName.value.isEmpty
                          ? 'Select New Video'
                          : 'Change Video')),
                    ),
                  ),
                  Obx(() => selectedVideoName.value.isNotEmpty
                      ? Container(
                    margin: const EdgeInsets.only(top: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.blue.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.video_file, color: Colors.blue, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'New: ${selectedVideoName.value}',
                            style: const TextStyle(fontSize: 14),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  )
                      : const SizedBox.shrink()),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final clubController = Get.find<ClubController>();

              // Update video details
              await clubController.updateVideoDetails(
                id: video.id,
                title: titleController.text,
                topic: topicController.text,
                level: selectedLevel.value,
              );

              // Update video file only if a new video was selected
              if (selectedVideoPath.value.isNotEmpty) {
                await clubController.updateVideoFile(video.id, selectedVideoPath.value);
              }

              Get.back();
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  void _showDeleteVideoConfirmation(BuildContext context, RecordedClass video) {
    Get.dialog(
      AlertDialog(
        title: const Text('Delete Video'),
        content: Text('Are you sure you want to delete "${video.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final clubController = Get.find<ClubController>();
              clubController.deleteClubVideo(video.id);
              Get.back();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _playVideo(RecordedClass recordedClass) {
    if (recordedClass.videoUrl != null && recordedClass.videoUrl!.isNotEmpty) {
      Get.to(() => const VideoDetailView(), arguments: recordedClass.id);
    } else {
      Get.to(() => const VideoDetailView(), arguments: recordedClass.id);
      Get.snackbar(
        'Video Unavailable', 
        'This video is not available for playback',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
    }
  }

  Widget _buildStudentsTab(BuildContext context) {
    final selectedClass = Rxn<SchoolClass>();
    final searchQuery = ''.obs;
    final schoolController = Get.find<SchoolController>();
    final authController = Get.find<AuthController>();
    final canManageClubs = authController.hasPermission('CLUBS:CREATE') ||
                          authController.hasPermission('CLUBS:EDIT') ||
                          authController.hasPermission('CLUBS:DELETE');
    
    final screenSize = MediaQuery.of(context).size;
    final isTablet = screenSize.width > 600;
    
    return SafeArea(
      child: Column(
        children: [
          // Header
          Container(
            margin: EdgeInsets.all(isTablet ? 20 : 16),
            padding: EdgeInsets.all(isTablet ? 24 : 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.white, Colors.indigo.withOpacity(0.05)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.indigo.withOpacity(0.1),
                  blurRadius: 15,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.indigo.shade600, Colors.indigo.shade400],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.school, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        'Student Club Management',
                        style: TextStyle(
                          fontSize: isTablet ? 24 : 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.indigo.shade700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                
                // Class Filter Dropdown
                Obx(() {
                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.indigo.withOpacity(0.3)),
                    ),
                    child: DropdownButtonFormField<SchoolClass>(
                      value: selectedClass.value,
                      decoration: InputDecoration(
                        labelText: 'Select Class',
                        prefixIcon: Icon(Icons.class_, color: Colors.indigo.shade600),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                      hint: Text('Choose a class to manage clubs', style: TextStyle(color: Colors.grey.shade600)),
                      dropdownColor: Colors.white,
                      icon: Icon(Icons.arrow_drop_down, color: Colors.indigo.shade600),
                      items: [
                        ...schoolController.classes.map((schoolClass) {
                          return DropdownMenuItem<SchoolClass>(
                            value: schoolClass,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: Colors.indigo.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Icon(Icons.class_, color: Colors.indigo.shade600, size: 16),
                                ),
                                const SizedBox(width: 12),
                                Flexible(
                                  child: Text(
                                    '${schoolClass.name} (${schoolClass.studentCount ?? 0} students)',
                                    style: const TextStyle(fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                      onChanged: (SchoolClass? value) {
                        selectedClass.value = value;
                        if (value != null) {
                          schoolController.getAllStudents(
                            schoolId: schoolController.selectedSchool.value!.id,
                            classId: value.id,
                          );
                        }
                      },
                    ),
                  );
                }),
                
                const SizedBox(height: 16),
                
                // Search Bar
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.indigo.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search students...',
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.indigo.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(Icons.search, color: Colors.indigo.shade600),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    ),
                    onChanged: (value) => searchQuery.value = value,
                  ),
                ),
              ],
            ),
          ),
          
          // Students List with Club Management
          Expanded(
            child: Obx(() {
              if (selectedClass.value == null) {
                return _buildEmptyState(
                  icon: Icons.class_,
                  title: 'Select a Class',
                  subtitle: 'Choose a class to manage student club memberships',
                );
              }
              
              if (schoolController.isLoading.value) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: Colors.indigo.shade600),
                      const SizedBox(height: 16),
                      Text('Loading students...', style: TextStyle(color: Colors.grey.shade600)),
                    ],
                  ),
                );
              }
              
              var filteredStudents = schoolController.students.toList();
              
              if (searchQuery.value.isNotEmpty) {
                final query = searchQuery.value.toLowerCase();
                filteredStudents = filteredStudents.where((student) => 
                  student.studentName.toLowerCase().contains(query) ||
                  (student.srId?.toLowerCase().contains(query) ?? false)
                ).toList();
              }
              
              if (filteredStudents.isEmpty) {
                return _buildEmptyState(
                  icon: Icons.person_search,
                  title: 'No students found',
                  subtitle: searchQuery.value.isNotEmpty 
                      ? 'Try adjusting your search terms'
                      : 'No students in this class',
                );
              }
              
              return Column(
                children: [
                  // Class Info Header with Add Button
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.indigo.shade50, Colors.white],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.indigo.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.class_, color: Colors.indigo.shade600),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                selectedClass.value!.name,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.indigo.shade700,
                                ),
                              ),
                              Text(
                                '${filteredStudents.length} students',
                                style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (canManageClubs)
                          ElevatedButton.icon(
                            onPressed: () => _showClubManagementDialog(
                              context, 
                              selectedClass.value!,
                              filteredStudents,
                            ),
                            icon: const Icon(Icons.group_add, size: 18),
                            label: Text('Add (${filteredStudents.length})'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.indigo.shade600,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  
                  // Students List
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: filteredStudents.length,
                      itemBuilder: (context, index) {
                        return _buildStudentCard(context, filteredStudents[index]);
                      },
                    ),
                  ),
                ],
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildStudentCard(BuildContext context, Student student) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: Colors.indigo.shade100,
              radius: 24,
              child: student.studentImage != null
                  ? ClipOval(
                      child: Image.network(
                        student.studentImage!,
                        width: 48,
                        height: 48,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Text(
                            student.studentName.substring(0, 1).toUpperCase(),
                            style: TextStyle(
                              color: Colors.indigo.shade700,
                              fontWeight: FontWeight.bold,
                            ),
                          );
                        },
                      ),
                    )
                  : Text(
                      student.studentName.substring(0, 1).toUpperCase(),
                      style: TextStyle(
                        color: Colors.indigo.shade700,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    student.studentName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ID: ${student.srId}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  if (student.fatherName != null)
                    Text(
                      'Father: ${student.fatherName}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[500],
                      ),
                    ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: student.isActive ? Colors.green.shade100 : Colors.red.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                student.isActive ? 'Active' : 'Inactive',
                style: TextStyle(
                  color: student.isActive ? Colors.green.shade700 : Colors.red.shade700,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showClubManagementDialog(BuildContext context, SchoolClass selectedClass, List<Student> students) {
    final selectedClubs = <String, bool>{}.obs;
    final isLoading = true.obs;
    final clubMembershipStatus = <String, bool>{}.obs; // Track if all students are in club
    
    // Get clubs connected to this class
    final classClubs = controller.getClubsByClass(selectedClass.id);
    
    // Load initial membership status
    Future.delayed(Duration.zero, () async {
      for (var club in classClubs) {
        // Check if all students in this class are already in this club
        final studentsInClub = students.where((student) => 
          student.clubs?.contains(club.id) ?? false
        ).length;
        
        final allStudentsInClub = studentsInClub == students.length && students.isNotEmpty;
        selectedClubs[club.id] = allStudentsInClub;
        clubMembershipStatus[club.id] = allStudentsInClub;

      }
      isLoading.value = false;
    });
    
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.indigo.shade600, Colors.indigo.shade400],
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(Icons.group_add, color: Colors.white, size: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Manage Club Memberships',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      '${selectedClass.name} - ${students.length} students',
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.6,
            ),
            child: Obx(() {
              if (isLoading.value) {
                return Container(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(color: Colors.indigo.shade600),
                      const SizedBox(height: 16),
                      const Text('Loading club information...'),
                    ],
                  ),
                );
              }
              
              if (classClubs.isEmpty) {
                return Container(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.info_outline, size: 48, color: Colors.grey.shade400),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No clubs found for this class',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey.shade700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Create clubs and assign them to this class first',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade500,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                );
              }
              
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.indigo.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info, color: Colors.indigo.shade600, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Select clubs to add/remove all students from this class',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.indigo.shade700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Flexible(
                    child: SingleChildScrollView(
                      child: Column(
                        children: classClubs.map((club) {
                          return Obx(() {
                            final isSelected = selectedClubs[club.id] ?? false;
                            final allStudentsInClub = clubMembershipStatus[club.id] ?? false;
                            
                            return Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: allStudentsInClub 
                                      ? [Colors.green.shade50, Colors.green.shade100]
                                      : [Colors.white, Colors.grey.shade50],
                                ),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: allStudentsInClub 
                                      ? Colors.green.shade300 
                                      : isSelected 
                                          ? Colors.indigo.shade300
                                          : Colors.grey.shade300,
                                  width: allStudentsInClub || isSelected ? 2 : 1,
                                ),
                                boxShadow: [
                                  if (isSelected || allStudentsInClub)
                                    BoxShadow(
                                      color: (allStudentsInClub ? Colors.green : Colors.indigo).withOpacity(0.1),
                                      blurRadius: 8,
                                      offset: const Offset(0, 2),
                                    ),
                                ],
                              ),
                              child: Theme(
                                data: Theme.of(context).copyWith(
                                  checkboxTheme: CheckboxThemeData(
                                    fillColor: MaterialStateProperty.resolveWith((states) {
                                      if (states.contains(MaterialState.selected)) {
                                        return Colors.indigo.shade600;
                                      }
                                      return Colors.transparent;
                                    }),
                                    checkColor: MaterialStateProperty.all(Colors.white),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                  ),
                                ),
                                child: CheckboxListTile(
                                  value: isSelected,
                                  onChanged: (bool? value) {
                                    selectedClubs[club.id] = value ?? false;
                                  },
                                  title: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                          color: allStudentsInClub 
                                              ? Colors.green.shade100
                                              : Colors.indigo.shade100,
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        child: Icon(
                                          _getCategoryIcon(club.category),
                                          color: allStudentsInClub 
                                              ? Colors.green.shade700
                                              : Colors.indigo.shade700,
                                          size: 20,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Text(
                                          club.name,
                                          style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: allStudentsInClub 
                                                ? Colors.green.shade800
                                                : Colors.black87,
                                            decoration: allStudentsInClub 
                                                ? TextDecoration.lineThrough 
                                                : null,
                                          ),
                                        ),
                                      ),
                                      if (allStudentsInClub)
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                          decoration: BoxDecoration(
                                            color: Colors.green.shade600,
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                          child: const Text(
                                            '✓ All Added',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                  subtitle: Padding(
                                    padding: const EdgeInsets.only(left: 52, top: 4),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          club.description,
                                          style: TextStyle(
                                            color: Colors.grey.shade600,
                                            fontSize: 13,
                                          ),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            Icon(Icons.people, size: 14, color: Colors.grey.shade500),
                                            const SizedBox(width: 4),
                                            Text(
                                              '${club.memberCount}/${club.maxMembers} members',
                                              style: TextStyle(
                                                color: Colors.grey.shade500,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                            const SizedBox(width: 12),
                                            Icon(Icons.category, size: 14, color: Colors.grey.shade500),
                                            const SizedBox(width: 4),
                                            Text(
                                              club.category,
                                              style: TextStyle(
                                                color: Colors.grey.shade500,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  controlAffinity: ListTileControlAffinity.leading,
                                ),
                              ),
                            );
                          });
                        }).toList(),
                      ),
                    ),
                  ),
                ],
              );
            }),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            style: TextButton.styleFrom(
              foregroundColor: Colors.grey.shade600,
            ),
            child: const Text('Cancel'),
          ),
          Obx(() {
            if (isLoading.value || classClubs.isEmpty) {
              return const SizedBox.shrink();
            }
            
            return ElevatedButton.icon(
              onPressed: controller.isLoading.value ? null : () async {
                try {
                  // Process each club selection
                  for (var entry in selectedClubs.entries) {
                    final clubId = entry.key;
                    final shouldToggle = entry.value != (clubMembershipStatus[clubId] ?? false);
                    
                    if (shouldToggle) {
                      // Call the toggle API for this class and club
                      await controller.toggleStudentsInClub(selectedClass.id, clubId);
                    }
                  }
                  
                  Get.back();
                  
                  // Reload students to refresh the view
                  final schoolController = Get.find<SchoolController>();
                  await schoolController.getAllStudents(
                    schoolId: schoolController.selectedSchool.value!.id,
                    classId: selectedClass.id,
                  );
                  
                } catch (e) {
                  Get.snackbar(
                    'Error',
                    'Failed to update club memberships',
                    backgroundColor: Colors.red,
                    colorText: Colors.white,
                    snackPosition: SnackPosition.BOTTOM,
                  );
                }
              },
              icon: controller.isLoading.value
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : const Icon(Icons.save, size: 18),
              label: Text(controller.isLoading.value ? 'Saving...' : 'Save Changes'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.indigo.shade600,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
            );
          }),
        ],
      ),
    );
  }
}